"""Flask backtest platform — login, expression input, metrics dashboard."""
import sys, os, uuid, threading, time, datetime, json, sqlite3
import numpy as np
import requests
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), '模型'))
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from data_pipeline import DataPipeline
from backtest_framework import BacktestEngine
from expression_parser import parse_expression, FIELDS_METADATA

app = Flask(__name__)
app.secret_key = 'quant2026_competition_key'

# USERS supports both username keys (backward compat) and email keys (registration).
# Value is always the password string.
USERS = {'admin': 'quant2026', 'guest': 'backtest'}

# Map email -> display name (set during registration, used for dashboard greeting)
USER_DISPLAY_NAMES = {}

def _is_valid_email(s: str) -> bool:
    """Simple email validation — must contain @ and . with something on each side."""
    s = (s or '').strip()
    return '@' in s and '.' in s and s.rfind('.') > s.find('@') > 0

pipeline = None
engine = None
factor_computer = None

# ---- Task 1: Async backtest task queue ----
_tasks = {}            # task_id -> {status, progress, result, error, created_at}
_tasks_lock = threading.Lock()

# ---- Task 4: Alpha history (legacy in-memory, migrated to SQLite on startup) ----
_alpha_history = []    # list of dicts — only used for one-time migration to SQLite
_alpha_history_lock = threading.Lock()

# ---- Community forum (legacy in-memory, migrated to SQLite on startup) ----
_community_posts = []  # list of dicts — only used for one-time migration to SQLite
_community_posts_lock = threading.Lock()

# ---- SQLite persistence ----
DB_PATH = os.path.join(os.path.dirname(__file__), 'backtest.db')

# ---- Simulation settings (global, reset on restart) ----
_sim_settings = {
    "universe": "csi800",
    "start_date": "2020-01-02",
    "end_date": "2023-12-29",
    "top_pct": 0.1,
    "delay_days": 1,
    "neutralize": "none"
}


def _init_db():
    """Create tables and migrate legacy in-memory data to SQLite."""
    conn = sqlite3.connect(DB_PATH)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('''CREATE TABLE IF NOT EXISTS alpha_history (
        id TEXT PRIMARY KEY, name TEXT, expression TEXT,
        timestamp TEXT, type TEXT, metrics_json TEXT,
        pnl_json TEXT, ic_json TEXT)''')
    conn.execute('''CREATE TABLE IF NOT EXISTS users (
            email TEXT PRIMARY KEY, password_hash TEXT, created_at TEXT)''')
    conn.execute('''CREATE TABLE IF NOT EXISTS community_posts (
        id TEXT PRIMARY KEY, author TEXT, expression TEXT,
        name TEXT, description TEXT, timestamp TEXT, alpha_id TEXT,
        likes INTEGER DEFAULT 0)''')
    conn.execute('''CREATE TABLE IF NOT EXISTS post_comments (
        id TEXT PRIMARY KEY, post_id TEXT, author TEXT,
        content TEXT, timestamp TEXT)''')
    conn.execute('''CREATE TABLE IF NOT EXISTS post_likes (
        post_id TEXT, user_email TEXT, PRIMARY KEY(post_id, user_email))''')
    # Migrations: add columns that may not exist in older DBs
    for stmt in [
        'ALTER TABLE users ADD COLUMN nickname TEXT',
        'ALTER TABLE community_posts ADD COLUMN alpha_id TEXT',
        'ALTER TABLE community_posts ADD COLUMN likes INTEGER DEFAULT 0',
        'ALTER TABLE alpha_history ADD COLUMN max_corr REAL',
    ]:
        try:
            conn.execute(stmt)
        except sqlite3.OperationalError:
            pass  # column already exists
    # Seed default users
    from werkzeug.security import generate_password_hash
    for email, pw in [('admin', 'quant2026'), ('guest', 'backtest')]:
        conn.execute('INSERT OR IGNORE INTO users(email, password_hash) VALUES(?,?)',
                     (email, generate_password_hash(pw)))
    conn.commit()

    # Migration: if DB is empty and in-memory lists have data, migrate them
    alpha_count = conn.execute('SELECT COUNT(*) FROM alpha_history').fetchone()[0]
    if alpha_count == 0:
        with _alpha_history_lock:
            if _alpha_history:
                for rec in _alpha_history:
                    conn.execute(
                        'INSERT OR IGNORE INTO alpha_history '
                        '(id, name, expression, timestamp, type, metrics_json, pnl_json, ic_json) '
                        'VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                        (rec['id'], rec.get('name', rec['expression'][:40]),
                         rec['expression'],
                         rec.get('timestamp', ''), rec.get('type', 'alpha'),
                         json.dumps(rec.get('metrics', {})),
                         json.dumps(rec.get('pnl_series', [])),
                         json.dumps(rec.get('ic_series', [])))
                    )
                conn.commit()
                _alpha_history.clear()

    posts_count = conn.execute('SELECT COUNT(*) FROM community_posts').fetchone()[0]
    if posts_count == 0:
        with _community_posts_lock:
            if _community_posts:
                for post in _community_posts:
                    conn.execute(
                        'INSERT OR IGNORE INTO community_posts '
                        '(id, author, expression, name, description, timestamp) '
                        'VALUES (?, ?, ?, ?, ?, ?)',
                        (post['id'], post.get('author', ''),
                         post.get('expression', ''),
                         post.get('name', post.get('expression', '')[:40]),
                         post.get('description', ''),
                         post.get('timestamp', ''))
                    )
                conn.commit()
                _community_posts.clear()

    conn.close()


def _row_to_record(row, include_pnl=False):
    """Convert a sqlite3.Row to the legacy dict format with parsed JSON fields."""
    rec = dict(row)
    # Parse metrics, replacing NaN with None
    try:
        import re
        raw = rec.pop('metrics_json')
        raw = re.sub(r'\bNaN\b', 'null', raw)
        rec['metrics'] = json.loads(raw)
    except Exception:
        rec['metrics'] = {}
    if include_pnl:
        try:
            raw = rec.pop('pnl_json'); raw = re.sub(r'\bNaN\b', 'null', raw)
            rec['pnl_series'] = json.loads(raw)
        except Exception: rec['pnl_series'] = []
        try:
            raw = rec.pop('ic_json'); raw = re.sub(r'\bNaN\b', 'null', raw)
            rec['ic_series'] = json.loads(raw)
        except Exception: rec['ic_series'] = []
    else:
        rec.pop('pnl_json', None)
        rec.pop('ic_json', None)
    return rec


# Initialize DB at module load time
_init_db()


def _cleanup_old_tasks():
    """Remove tasks older than 1 hour."""
    while True:
        time.sleep(300)  # every 5 minutes
        now = time.time()
        with _tasks_lock:
            expired = [tid for tid, t in _tasks.items()
                       if now - t.get('created_at', now) > 3600]
            for tid in expired:
                del _tasks[tid]


# Start cleanup daemon thread
_cleanup_thread = threading.Thread(target=_cleanup_old_tasks, daemon=True)
_cleanup_thread.start()


def _to_json_safe(obj):
    """Recursively convert numpy types to Python native types for JSON serialization."""
    import numpy as np, math
    if isinstance(obj, (np.integer, np.bool_)): return int(obj)
    if isinstance(obj, (np.floating,)): v=float(obj); return None if math.isnan(v) or math.isinf(v) else v
    if isinstance(obj, float): return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, np.ndarray): return obj.tolist()
    if isinstance(obj, dict): return {k: _to_json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)): return [_to_json_safe(v) for v in obj]
    return obj


def get_engine():
    global pipeline, engine, factor_computer
    if pipeline is None:
        pipeline = DataPipeline()
        engine = BacktestEngine(pipeline)
        from factor_library import FactorComputer
        factor_computer = FactorComputer(pipeline)
        print('[Init] DataPipeline + BacktestEngine + FactorComputer ready.')
    return pipeline, engine, factor_computer



def _add_to_history(expression: str, metrics: dict, alpha_type: str = 'alpha', name: str = None):
    """Persist a backtest result to SQLite alpha history."""
    _internal_keys = {'_factor_array', '_direction', 'ic_series', 'pnl_series'}
    if name is None:
        name = expression[:40] + ('...' if len(expression) > 40 else '')

    entry_id = str(uuid.uuid4())
    timestamp = datetime.datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
    metrics_json = json.dumps({k: v for k, v in metrics.items() if k not in _internal_keys})
    pnl_json = json.dumps(metrics.get('pnl_series', []))
    ic_json = json.dumps(metrics.get('ic_series', []))

    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        'INSERT INTO alpha_history (id, name, expression, timestamp, type, '
        'metrics_json, pnl_json, ic_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        (entry_id, name, expression, timestamp, alpha_type, metrics_json, pnl_json, ic_json)
    )
    conn.commit()
    conn.close()
    return entry_id



def _resolve_display_name(email_or_name: str) -> str:
    """Look up nickname from users table; fall back to email prefix if no nickname."""
    conn = sqlite3.connect(DB_PATH)
    row = conn.execute('SELECT nickname FROM users WHERE email=?', (email_or_name,)).fetchone()
    conn.close()
    if row and row[0]:
        return row[0]
    if '@' in (email_or_name or ''):
        return email_or_name.split('@')[0]
    return email_or_name or '匿名'


def _build_post_dict(row: dict, include_author_raw: bool = False) -> dict:
    """Convert a community_posts row (possibly with JOINed alpha columns) into a response dict.

    Handles alpha_ref construction from joined alpha_history columns.
    Looks up display nickname for author if stored as email.
    """
    post = dict(row)
    # Build alpha_ref from joined alpha_history data
    alpha_id = post.get('alpha_id')
    alpha_expr = post.pop('ref_expr', None)
    alpha_metrics_raw = post.pop('ref_metrics', None)
    if alpha_id and alpha_expr:
        metrics = {}
        if alpha_metrics_raw:
            try:
                metrics = json.loads(alpha_metrics_raw) if isinstance(alpha_metrics_raw, str) else alpha_metrics_raw
            except Exception:
                pass
        ref_pnl_raw = post.pop('ref_pnl', None)
        pnl_series = []
        if ref_pnl_raw:
            try:
                pnl_series = json.loads(ref_pnl_raw) if isinstance(ref_pnl_raw, str) else ref_pnl_raw
            except Exception: pass
        post['alpha_ref'] = {
            'expression': alpha_expr,
            'metrics': {k: metrics.get(k) for k in
                        ('pearson_ic', 'annual_excess', 'sharpe', 'fitness', 'turnover', 'max_drawdown')},
            'pnl_series': pnl_series,
        }
    # Resolve display name
    raw_author = post.get('author', '')
    post['author_display'] = _resolve_display_name(raw_author)
    return post

# ======================== ROUTES ========================

@app.route('/')
def index():
    if 'user' not in session:
        return redirect(url_for('login'))
    return redirect(url_for('dashboard'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip().lower()
        password = request.form.get('password', '')
        from werkzeug.security import check_password_hash
        # Check SQLite users table first
        conn = sqlite3.connect(DB_PATH)
        row = conn.execute('SELECT password_hash FROM users WHERE email=?', (username,)).fetchone()
        conn.close()
        if row and check_password_hash(row[0], password):
            session['user'] = username
            return redirect(url_for('dashboard'))
        return render_template('login.html', error='用户名/邮箱或密码错误')
    return render_template('login.html', error=None)


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '').strip()
        confirm = request.form.get('confirm_password', '').strip()
        from werkzeug.security import generate_password_hash

        if not _is_valid_email(email):
            return render_template('login.html', error='邮箱格式不正确', mode='register')
        conn = sqlite3.connect(DB_PATH)
        existing = conn.execute('SELECT 1 FROM users WHERE email=?',(email,)).fetchone()
        conn.close()
        if existing:
            return render_template('login.html', error='该邮箱已注册', mode='register')
        if len(password) < 6:
            return render_template('login.html', error='密码至少6位', mode='register')
        if password != confirm:
            return render_template('login.html', error='两次密码不一致', mode='register')

        nickname = request.form.get('nickname', '').strip()

        conn = sqlite3.connect(DB_PATH)
        conn.execute('INSERT INTO users(email,password_hash,created_at,nickname) VALUES(?,?,?,?)',
                     (email, generate_password_hash(password), datetime.datetime.now().isoformat(), nickname or None))
        conn.commit()
        conn.close()
        session['user'] = email
        return redirect(url_for('dashboard'))

    return render_template('login.html', error=None, mode='register')


@app.route('/dashboard_v2')
def dashboard_v2():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard_v2.html')
    
@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))


@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    raw_user = session['user']
    display_name = _resolve_display_name(raw_user)
    return render_template('dashboard.html', username=display_name)


@app.route('/alpha_history')
def alpha_history_page():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('alpha_history.html')


@app.route('/data_fields')
def data_fields_page():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('data_fields.html')


@app.route('/operators')
def operators_page():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('operators.html')


@app.route('/correlation')
def correlation_page():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('correlation.html')


@app.route('/compare')
def compare_page():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('compare.html')


# ---- Settings endpoints ----

@app.route('/api/settings', methods=['GET'])
def api_get_settings():
    """Return current simulation settings."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401
    return jsonify(_sim_settings)


@app.route('/api/settings', methods=['POST'])
def api_update_settings():
    """Update simulation settings."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401
    data = request.get_json()
    if not data:
        return jsonify({'error': '请求体为空'}), 400
    for key in ('start_date', 'end_date', 'top_pct', 'delay_days', 'neutralize'):
        if key in data:
            _sim_settings[key] = data[key]
    return jsonify({'success': True, 'settings': _sim_settings})


# ---- Task 1: Async backtest (start + status) ----

@app.route('/api/debug/minute', methods=['GET'])
def api_debug_minute():
    """Debug endpoint: verify minute-derived field computation."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401
    import expression_parser as ep
    import numpy as np
    pipeline, engine, fc = get_engine()
    r = ep._compute_all_minute_derived(pipeline)
    cl = r['close_location']
    n_valid = np.isfinite(cl).sum()
    t0 = pipeline.date_to_idx['2020-01-02']
    t1 = min(pipeline.date_to_idx['2023-12-29'] + 1, pipeline.n_dates)
    cl_train = cl[t0:t1]
    valid_days = sum(1 for t in range(cl_train.shape[0]) if np.isfinite(cl_train[t]).sum() >= 100)
    return jsonify({
        'file': ep.__file__,
        'total_valid_cells': int(n_valid),
        'valid_days_2020_2023': valid_days,
        'total_days_2020_2023': t1 - t0,
        'cached': ep._minute_batch_cache is not None,
    })


@app.route('/api/backtest', methods=['POST'])
def api_backtest_legacy():
    """Synchronous backtest — runs full pipeline and returns results directly."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401

    data = request.get_json()
    expression = data.get('expression', '')
    if not expression:
        return jsonify({'error': '表达式不能为空'}), 400

    neutralize = data.get('neutralize', 'none')
    try:
        pipeline, engine, fc = get_engine()
        factor = parse_expression(expression, pipeline, fc)

        t0 = pipeline.date_to_idx['2020-01-02']
        t1 = min(pipeline.date_to_idx['2023-12-29'] + 1, pipeline.n_dates)
        factor_train = factor[t0:t1]
        label_train = pipeline.fields['Label'][t0:t1]
        univ_train = pipeline.universe_mask[t0:t1]

        if neutralize == 'market_cap':
            adjf = np.clip(np.where(np.isnan(pipeline.fields.get('I_D_ADJFACTOR', np.ones_like(factor_train[0]))), 1.0,
                                    pipeline.fields.get('I_D_ADJFACTOR', np.ones_like(factor_train[0]))), 0.01, 100)
            mcap = pipeline.fields['I_D_CLOSE_ORI'] * adjf * pipeline.fields.get('I_D_TOTAL_SHARES', np.ones_like(factor_train[0]))
            mcap_train = mcap[t0:t1]
            for t in range(factor_train.shape[0]):
                valid = ~np.isnan(factor_train[t]) & ~np.isnan(mcap_train[t])
                if valid.sum() < 100: continue
                log_mcap = np.log(np.maximum(mcap_train[t, valid], 1))
                gids = np.floor(np.digitize(log_mcap, np.percentile(log_mcap, np.arange(0,101,10)))/10).astype(int)
                fv = factor_train[t, valid].copy()
                for g in np.unique(gids):
                    gm = gids == g
                    if gm.sum() >= 10: fv[gm] = fv[gm] - np.nanmean(fv[gm])
                factor_train[t, valid] = fv

        result = engine.full_evaluation(factor_train, univ_train, label=label_train)
        metrics = _compute_metrics_from_result(factor_train, label_train, univ_train, result)
        metrics.pop('factor_array', None)
        metrics.pop('_factor_array', None)
        metrics.pop('_direction', None)
        metrics.pop('direction', None)

        # Also save to history
        _add_to_history(expression, metrics, 'alpha')

        # Only return display metrics (not internal arrays)
        display_keys = ['pearson_ic','rank_ic','icir','ic_positive_ratio',
            'annual_excess','sharpe','fitness','returns','max_drawdown',
            'turnover','margin_bps','sortino','win_rate','n_days',
            'ic_series','pnl_series']
        display = {k:v for k,v in metrics.items() if k in display_keys}
        return jsonify(_to_json_safe({'success': True, **display}))
    except Exception as e:
        import traceback; traceback.print_exc()
        return jsonify({'error': f'回测失败: {str(e)}'}), 400


@app.route('/api/backtest/start', methods=['POST'])
def api_backtest_start():
    """Start an async backtest. Returns {task_id} immediately.

    Accepts optional 'neutralize' field in JSON body:
      - "none" (default): no neutralization
      - "market_cap": cross-sectional market cap neutralization
    """
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401

    data = request.get_json()
    expression = data.get('expression', '')
    if not expression:
        return jsonify({'error': '表达式不能为空'}), 400

    neutralize = data.get('neutralize', 'none')
    if neutralize not in ('none', 'market_cap'):
        return jsonify({'error': f'不支持的中性化方式: {neutralize}'}), 400

    start_date = data.get('start_date')
    end_date = data.get('end_date')
    top_pct = data.get('top_pct')

    task_id = _start_backtest_task(expression, neutralize, start_date, end_date, top_pct)
    return jsonify({'task_id': task_id, 'neutralize': neutralize})


@app.route('/api/backtest/status/<task_id>', methods=['GET'])
def api_backtest_status(task_id):
    """Poll backtest status. Returns {status, progress, result, error}."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401

    with _tasks_lock:
        task = _tasks.get(task_id)

    if task is None:
        return jsonify({'error': '任务不存在或已过期'}), 404

    resp = {
        'task_id': task_id,
        'status': task['status'],
        'progress': task['progress'],
    }
    if task['status'] == 'done':
        resp['result'] = task.get('result')
    elif task['status'] == 'error':
        resp['error'] = task.get('error')
    return jsonify(resp)


@app.route('/api/backtest/cancel/<task_id>', methods=['POST'])
def api_backtest_cancel(task_id):
    """Cancel a running backtest."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401
    with _tasks_lock:
        task = _tasks.get(task_id)
        if task:
            task['status'] = 'error'
            task['error'] = '用户取消'
    return jsonify({'status': 'cancelled'})


def _start_backtest_task(expression: str, neutralize: str = 'none',
                         start_date: str = None, end_date: str = None,
                         top_pct: float = None) -> str:
    """Create a new backtest task and spawn a background thread. Returns task_id."""
    task_id = str(uuid.uuid4())
    with _tasks_lock:
        _tasks[task_id] = {
            'status': 'running',
            'progress': 0,
            'result': None,
            'error': None,
            'created_at': time.time(),
            'neutralize': neutralize,
            'start_date': start_date or _sim_settings['start_date'],
            'end_date': end_date or _sim_settings['end_date'],
            'top_pct': top_pct if top_pct is not None else _sim_settings['top_pct'],
        }

    thread = threading.Thread(
        target=_run_backtest_task, args=(task_id, expression, neutralize), daemon=True
    )
    thread.start()
    return task_id


def _run_backtest_task(task_id: str, expression: str, neutralize: str = 'none'):
    """Background worker that runs the backtest and updates _tasks."""
    try:
        # Progress: parse expression
        _update_task(task_id, 'running', 5)

        pipeline, engine, fc = get_engine()
        _update_task(task_id, 'running', 15)

        # Progress: compute factor + evaluate
        factor = parse_expression(expression, pipeline, fc)
        _update_task(task_id, 'running', 20)

        # Read custom settings from task dict
        with _tasks_lock:
            task_cfg = _tasks.get(task_id, {})
        start_date = task_cfg.get('start_date', '2020-01-02')
        end_date = task_cfg.get('end_date', '2023-12-29')
        top_pct = task_cfg.get('top_pct', 0.1)

        t0 = pipeline.date_to_idx[start_date]
        t1 = min(pipeline.date_to_idx[end_date] + 1, pipeline.n_dates)
        factor_train = factor[t0:t1]
        label_train = pipeline.fields['Label'][t0:t1]
        univ_train = pipeline.universe_mask[t0:t1]

        # ---- Market cap neutralization (WQ-style: subtract group mean) ----
        if neutralize == 'market_cap':
            adjf = np.clip(np.where(np.isnan(pipeline.fields['I_D_ADJFACTOR']), 1.0,
                                    pipeline.fields.get('I_D_ADJFACTOR', np.ones_like(factor_train[0]))), 0.01, 100)
            mcap = pipeline.fields['I_D_CLOSE_ORI'] * adjf * pipeline.fields.get('I_D_TOTAL_SHARES', pipeline.fields.get('I_D_SHARE_LIQA', np.ones_like(factor_train[0])))
            mcap_train = mcap[t0:t1]
            # Bucket stocks into market cap groups per day
            for t in range(factor_train.shape[0]):
                valid = ~np.isnan(factor_train[t]) & ~np.isnan(mcap_train[t])
                if valid.sum() < 100:
                    continue
                # Group by log market cap quantiles (10 groups)
                log_mcap = np.log(np.maximum(mcap_train[t, valid], 1))
                group_ids = np.floor(np.digitize(log_mcap, np.percentile(log_mcap, np.arange(0, 101, 10))) / 10).astype(int)
                fv = factor_train[t, valid].copy()
                for g in np.unique(group_ids):
                    gmask = group_ids == g
                    if gmask.sum() >= 10:
                        fv[gmask] = fv[gmask] - np.nanmean(fv[gmask])
                factor_train[t, valid] = fv

        _update_task(task_id, 'running', 30)

        result = engine.full_evaluation(factor_train, univ_train, label=label_train)
        _update_task(task_id, 'running', 70)

        # Progress: evaluate metrics (80 -> 90)
        metrics = _compute_metrics_from_result(
            factor_train, label_train, univ_train, result, top_pct=top_pct
        )
        _update_task(task_id, 'running', 90)

        # Progress: compute PnL series (90 -> 100)
        # PnL already computed inside _compute_metrics_from_result
        _update_task(task_id, 'running', 95)

        # Finalize: store numpy array at task level (not in JSON result)
        factor_arr = metrics.pop('factor_array', None)
        with _tasks_lock:
            _tasks[task_id]['status'] = 'done'
            _tasks[task_id]['progress'] = 100
            _tasks[task_id]['result'] = _to_json_safe({'success': True, **metrics})
            _tasks[task_id]['_factor_array'] = factor_arr

        # Auto-save to history
        _add_to_history(expression, metrics, 'alpha')

    except Exception as e:
        import traceback
        traceback.print_exc()
        with _tasks_lock:
            _tasks[task_id]['status'] = 'error'
            _tasks[task_id]['progress'] = 0
            _tasks[task_id]['error'] = f'回测失败: {str(e)}'


def _compute_metrics_from_result(factor_train, label_train, univ_train, result, top_pct=0.1):
    """Extract all metrics from a factor evaluation result. Used by both
    async backtest and superalpha."""
    import math
    # Direction: always 1 (high factor value = long). User controls sign via -expression.
    direction = 1

    n_dates = factor_train.shape[0]
    daily_excess = []  # Top10% - Market average (competition long-only excess)
    daily_top_set = []
    for t in range(n_dates):
        f = factor_train[t]
        l = label_train[t]
        valid = univ_train[t] & (~np.isnan(f)) & (~np.isnan(l))
        if valid.sum() < 100:
            daily_excess.append(None)
            daily_top_set.append(set())
            continue
        fv, lv = f[valid], l[valid]
        n_top = max(1, int(valid.sum() * top_pct))
        order = np.argsort(fv)
        if direction > 0:
            top_idx = order[-n_top:]
        else:
            top_idx = order[:n_top]
        long_ret = float(np.nanmean(lv[top_idx]))
        mkt_ret = float(np.nanmean(lv))
        daily_excess.append(long_ret - mkt_ret)
        global_idx = np.where(valid)[0][top_idx]
        daily_top_set.append(set(global_idx))

    # All metrics based on long-only Top10% excess (competition standard)
    excess_arr = np.array([x for x in daily_excess if x is not None])
    excess_mean = float(np.mean(excess_arr))
    excess_std = float(np.std(excess_arr))
    ann_excess = excess_mean * 250
    wq_sharpe = ann_excess / (excess_std * np.sqrt(250) + 1e-10)

    # Turnover
    turnovers = []
    for t in range(1, len(daily_top_set)):
        prev = daily_top_set[t - 1]
        curr = daily_top_set[t]
        if len(prev) > 0 and len(curr) > 0:
            overlap = len(prev & curr)
            to = 1.0 - overlap / max(len(prev), len(curr))
            turnovers.append(to)
    avg_turnover = float(np.mean(turnovers)) if turnovers else 0.0

    # Fitness: based on excess returns and turnover
    fitness_denom = max(avg_turnover, 0.125)
    wq_fitness = wq_sharpe * np.sqrt(abs(ann_excess) / fitness_denom) if ann_excess != 0 else 0.0

    # Drawdown (based on cumulative excess)
    cum = 0.0
    peak = 0.0
    max_dd = 0.0
    cum_pnl = []
    for r in daily_excess:
        if r is not None:
            cum += r
            if cum > peak:
                peak = cum
            dd = peak - cum
            if dd > max_dd:
                max_dd = dd
        cum_pnl.append(float(cum * 100))

    wq_margin = float(excess_mean / (np.mean(np.abs(excess_arr)) + 1e-10) * 10000)

    neg_excess = excess_arr[excess_arr < 0]
    downside_std = float(np.std(neg_excess)) if len(neg_excess) > 0 else excess_std
    sortino = ann_excess / (downside_std * np.sqrt(250) + 1e-10)

    win_rate = float((excess_arr > 0).mean())

    ic_series = result.get('ic_series', np.array([]))
    ic_series_display = [round(float(x), 4) if not np.isnan(x) else None
                         for x in ic_series[-60:]]
    # Clean NaN from pnl_series
    pnl_display = [None if x is None or math.isnan(float(x)) else float(x) for x in cum_pnl]

    # Also store the full factor_train for superalpha combination
    def safe_round(val, ndigits):
        try:
            v = float(val)
            return round(v, ndigits) if not math.isnan(v) and not math.isinf(v) else None
        except Exception: return None

    return {
        'pearson_ic': safe_round(result.get('mean_pearson_ic', 0), 4),
        'rank_ic': safe_round(result.get('mean_rank_ic', 0), 4),
        'icir': safe_round(result.get('icir', 0), 3),
        'ic_positive_ratio': safe_round(result.get('ic_positive_ratio', 0), 3),
        'annual_excess': safe_round(ann_excess, 4),
        'sharpe': safe_round(wq_sharpe, 3),
        'fitness': safe_round(wq_fitness, 3),
        'returns': safe_round(ann_excess, 4),
        'max_drawdown': safe_round(max_dd, 4),
        'turnover': safe_round(avg_turnover, 4),
        'margin_bps': safe_round(wq_margin, 1),
        'sortino': safe_round(sortino, 3),
        'win_rate': safe_round(win_rate, 3),
        'n_days': int(result['n_eval_days']) if result.get('n_eval_days') else 0,
        'ic_series': ic_series_display,
        'pnl_series': pnl_display,
        # Internal: not serialized to client but used by superalpha
        '_factor_array': factor_train,
        '_direction': direction,
    }


def _update_task(task_id, status, progress):
    """Thread-safe task progress update."""
    with _tasks_lock:
        if task_id in _tasks:
            _tasks[task_id]['status'] = status
            _tasks[task_id]['progress'] = progress


# ---- Task 2: Updated /api/fields (categorized) ----

@app.route('/api/fields')
def api_fields():
    return jsonify({
        '价格类': ['close', 'open', 'high', 'low', 'preclose'],
        '收益类': ['morning_return', 'afternoon_return', 'first30min_return',
                  'last30min_return', 'body_return', 'auction_return'],
        '成交量类': ['volume', 'amount', 'volume_profile_ratio', 'turnover_rate'],
        '波动类': ['intraday_volatility', 'upper_shadow_pct', 'lower_shadow_pct'],
        '分钟模拟类': ['morning_return', 'afternoon_return', 'first30min_return',
                     'last30min_return', 'body_return', 'upper_shadow_pct',
                     'lower_shadow_pct', 'auction_return',
                     'intraday_volatility'],
        '预计算因子': ['ret_20d', 'ret_60d', 'ret_120d_skip5', 'ret_5d',
                     'sharpe_60d', 'mom_vol_adj', 'max_dd_60d', 'close_vs_high_20d',
                     'rev_1d', 'rev_5d', 'rev_overnight', 'abnormal_vol_rev',
                     'vol_20d', 'vol_60d', 'vol_ratio', 'downside_vol_60d',
                     'skewness_60d', 'turnover_5d', 'amihud_20d', 'log_dollar_vol',
                     'upper_shadow', 'lower_shadow', 'body_ratio', 'gap_up',
                     'vpin', 'rsi_14', 'bollinger_pos', 'beta_60d', 'market_cap_rank'],
        'operators': ['ts_delta(x,d)', 'ts_mean(x,d)', 'ts_std(x,d)', 'ts_rank(x,d)',
                      'ts_max(x,d)', 'ts_min(x,d)', 'ts_sum(x,d)', 'ts_corr(x,y,d)',
                      'rank(x)', 'zscore(x)', 'demean(x)', 'signed_power(x,e)',
                      'group_neutralize(x,group)', 'group_rank(x,group)', 'group_zscore(x,group)',
                      'ts_delay(x,d)', 'ts_decay_linear(x,d)', 'ts_backfill(x)',
                      'ts_regression(y,x,d,lag)'],
    })


# ---- Task 5: /api/datafields (metadata-rich field listing) ----

@app.route('/api/datafields')
def api_datafields():
    """Return all available data fields with metadata, grouped by category."""
    categories_order = ['价格类', '收益类', '量价类', '波动类', '微观结构类',
                        '动量因子', '反转因子', '波动率因子', '量价因子', '形态因子',
                        '微观结构因子', '跨模态因子', '技术指标']
    grouped = {cat: [] for cat in categories_order}

    for field_name, meta in FIELDS_METADATA.items():
        cat = meta['category']
        if cat not in grouped:
            grouped[cat] = []
        grouped[cat].append({
            'name': field_name,
            'chinese_name': meta.get('chinese_name', field_name),
            'category': meta['category'],
            'description': meta['description'],
            'calculation': meta['calculation'],
        })

    # Remove empty categories
    grouped = {k: v for k, v in grouped.items() if v}
    return jsonify({'categories': grouped})


# ---- Task 3: SuperAlpha ----

@app.route('/api/superalpha', methods=['POST'])
def api_superalpha():
    """Combine multiple alphas via weighted factor average and backtest.

    Accepts TWO input formats:

    Format A (direct expressions):
      {"expressions": ["expr1", "expr2", ...], "weights": [0.5, 0.5, ...],
       "neutralize": "none"|"market_cap"}

    Format B (alpha_ids from history):
      {"alpha_ids": ["id1", "id2", ...], "neutralize": "none"|"market_cap"}
      Looks up expressions from alpha_history, re-parses each, uses equal weight.
    """
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401

    data = request.get_json()
    neutralize = data.get('neutralize', 'none')

    # ---- Determine input format ----
    direct_expressions = data.get('expressions', None)
    alpha_ids = data.get('alpha_ids', [])

    if direct_expressions is not None:
        # Format A: direct expressions with optional weights
        expressions = [e.strip() for e in direct_expressions if (e or '').strip()]
        weights_in = data.get('weights', None)

        if len(expressions) < 1:
            return jsonify({'error': '至少需要1个表达式'}), 400
        if len(expressions) > 100:
            return jsonify({'error': '最多100个表达式'}), 400

        if weights_in is None:
            weights = [1.0 / len(expressions)] * len(expressions)
        else:
            if len(weights_in) != len(expressions):
                return jsonify({'error': 'weights长度必须与expressions一致'}), 400
            w_sum = sum(weights_in)
            if w_sum <= 0:
                return jsonify({'error': '权重之和必须大于0'}), 400
            weights = [w / w_sum for w in weights_in]

        # Use sequential IDs for sub-alpha entries
        alpha_ids_for_subs = ['direct_' + str(i) for i in range(len(expressions))]

    elif alpha_ids and len(alpha_ids) >= 1:
        # Format B: look up from history, equal weight
        if len(alpha_ids) > 100:
            return jsonify({'error': '最多100个Alpha'}), 400

        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        placeholders = ','.join(['?' for _ in alpha_ids])
        rows = conn.execute(
            f'SELECT id, expression FROM alpha_history WHERE id IN ({placeholders})',
            alpha_ids
        ).fetchall()
        conn.close()

        id_to_expr = {row['id']: row['expression'] for row in rows}

        expressions = []
        alpha_ids_for_subs = []
        for aid in alpha_ids:
            expr = id_to_expr.get(aid)
            if not expr:
                return jsonify({'error': f'Alpha ID {aid} 不存在于历史记录中'}), 404
            if expr.startswith('superalpha('):
                return jsonify({'error': f'Alpha #{aid[:8]} 是组合结果，不能再次组合。请选择单因子'}), 400
            expressions.append(expr)
            alpha_ids_for_subs.append(aid)

        n_alphas = len(expressions)
        weights = [1.0 / n_alphas] * n_alphas

    else:
        return jsonify({'error': '请提供 expressions（表达式列表）或 alpha_ids（历史记录ID列表）'}), 400

    try:
        pipeline, engine, fc = get_engine()

        t0 = pipeline.date_to_idx['2020-01-02']
        t1 = min(pipeline.date_to_idx['2023-12-29'] + 1, pipeline.n_dates)
        label_train = pipeline.fields['Label'][t0:t1]
        univ_train = pipeline.universe_mask[t0:t1]

        sub_results = []
        factor_arrays = []

        # Step 1: Re-parse each expression and evaluate individually
        for i, expr in enumerate(expressions):
            factor = parse_expression(expr, pipeline, fc)
            f_train = factor[t0:t1]
            factor_arrays.append(f_train)

            result = engine.full_evaluation(f_train, univ_train, label=label_train)
            metrics = _compute_metrics_from_result(f_train, label_train, univ_train, result)

            sub_results.append({
                'alpha_id': alpha_ids_for_subs[i],
                'expression': expr,
                'weight': round(weights[i], 4),
                'metrics': {k: v for k, v in metrics.items()
                            if k not in ('_factor_array', '_direction',
                                         'ic_series', 'pnl_series')},
                'ic_series': metrics.get('ic_series', []),
                'pnl_series': metrics.get('pnl_series', []),
            })

        # Step 2: zscore-normalize each factor cross-sectionally, then equal-weight average
        factor_zscored = []
        for fa in factor_arrays:
            f_mean = np.nanmean(fa, axis=1, keepdims=True)
            f_std = np.nanstd(fa, axis=1, keepdims=True) + 1e-10
            factor_zscored.append((fa - f_mean) / f_std)

        n_dates, n_stocks = factor_arrays[0].shape
        combined = np.zeros((n_dates, n_stocks), dtype=np.float32)
        for w, fz in zip(weights, factor_zscored):
            valid = ~np.isnan(fz)
            combined[valid] += w * fz[valid]

        # NaN where all factors are NaN
        all_nan = np.all([np.isnan(fa) for fa in factor_arrays], axis=0)
        combined[all_nan] = np.nan

        # ---- Market cap neutralization for combined factor ----
        if neutralize == 'market_cap':
            from scipy import stats
            adjf = np.clip(np.where(np.isnan(pipeline.fields['I_D_ADJFACTOR']), 1.0,
                                    pipeline.fields.get('I_D_ADJFACTOR', np.ones_like(combined[0]))), 0.01, 100)
            mcap = pipeline.fields['I_D_CLOSE_ORI'] * adjf * pipeline.fields.get('I_D_TOTAL_SHARES', pipeline.fields.get('I_D_SHARE_LIQA', np.ones_like(combined[0])))
            mcap_train = mcap[t0:t1]
            for t in range(combined.shape[0]):
                valid = ~np.isnan(combined[t]) & ~np.isnan(mcap_train[t])
                if valid.sum() < 100:
                    continue
                log_mcap = np.log(np.maximum(mcap_train[t, valid], 1))
                group_ids = np.floor(np.digitize(log_mcap, np.percentile(log_mcap, np.arange(0, 101, 10))) / 10).astype(int)
                cv = combined[t, valid].copy()
                for g in np.unique(group_ids):
                    gmask = group_ids == g
                    if gmask.sum() >= 10:
                        cv[gmask] = cv[gmask] - np.nanmean(cv[gmask])
                combined[t, valid] = cv

        # Step 3: Evaluate the combined factor
        combined_result = engine.full_evaluation(combined, univ_train, label=label_train)
        combined_metrics = _compute_metrics_from_result(
            combined, label_train, univ_train, combined_result
        )

        # Clean up internal fields before returning
        combined_metrics_clean = {k: v for k, v in combined_metrics.items()
                                  if k not in ('_factor_array', '_direction')}

        # Step 4: Build the response
        response = {
            'success': True,
            'type': 'superalpha',
            'combined_metrics': combined_metrics_clean,
            'sub_alphas': sub_results,
        }

        # Save to history
        combined_expression = 'superalpha(' + ' + '.join(expressions) + ')'
        _add_to_history(combined_expression, combined_metrics, 'superalpha')

        return jsonify(response)

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'SuperAlpha计算失败: {str(e)}'}), 400


# ---- Task 4: Alpha History CRUD (SQLite-backed) ----

@app.route('/api/alpha/history', methods=['GET'])
def api_alpha_history():
    """Return all alpha history records (newest first)."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        'SELECT * FROM alpha_history ORDER BY timestamp DESC'
    ).fetchall()
    conn.close()

    records = [_row_to_record(row) for row in rows]

    # Ensure all records have a name field (backward compatibility)
    for rec in records:
        if 'name' not in rec or not rec['name']:
            expr = rec.get('expression', '')
            rec['name'] = expr[:40] + ('...' if len(expr) > 40 else '')

    return jsonify({'count': len(records), 'records': records})


@app.route('/api/alpha/history/<record_id>/pnl', methods=['GET'])
def api_alpha_history_pnl(record_id):
    """Return PnL data for a single record (lazy-loaded)."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    row = conn.execute('SELECT pnl_json, ic_json FROM alpha_history WHERE id=?', (record_id,)).fetchone()
    conn.close()
    if not row:
        return jsonify({'error': '记录不存在'}), 404
    return jsonify({
        'pnl_series': json.loads(row['pnl_json'] or '[]'),
        'ic_series': json.loads(row['ic_json'] or '[]'),
    })


@app.route('/api/alpha/history/<record_id>', methods=['DELETE'])
def api_alpha_history_delete(record_id):
    """Delete a specific history record by ID."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.execute('DELETE FROM alpha_history WHERE id = ?', (record_id,))
    conn.commit()
    deleted = cursor.rowcount
    conn.close()

    if deleted:
        return jsonify({'success': True, 'deleted': record_id})
    return jsonify({'error': '记录不存在'}), 404


@app.route('/api/alpha/history/<record_id>/rename', methods=['POST'])
def api_alpha_history_rename(record_id):
    """Rename a specific history record."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401

    data = request.get_json()
    new_name = (data.get('name', '') or '').strip()
    if not new_name:
        return jsonify({'error': '名称不能为空'}), 400
    if len(new_name) > 200:
        return jsonify({'error': '名称不超过200字符'}), 400

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.execute(
        'UPDATE alpha_history SET name = ? WHERE id = ?', (new_name, record_id)
    )
    conn.commit()
    updated = cursor.rowcount
    conn.close()

    if updated:
        return jsonify({'success': True, 'id': record_id, 'name': new_name})
    return jsonify({'error': '记录不存在'}), 404


@app.route('/api/alpha/compare', methods=['POST'])
def api_alpha_compare():
    """Compare 2-5 alphas side-by-side. Returns metrics, pnl_series, ic_series for each."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401

    data = request.get_json()
    ids = data.get('ids', [])

    if not ids or len(ids) < 2:
        return jsonify({'error': '至少需要选择2个Alpha'}), 400
    if len(ids) > 5:
        return jsonify({'error': '最多选择5个Alpha'}), 400

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    placeholders = ','.join(['?' for _ in ids])
    rows = conn.execute(
        f'SELECT * FROM alpha_history WHERE id IN ({placeholders})', ids
    ).fetchall()
    conn.close()

    id_to_record = {}
    for row in rows:
        rec = _row_to_record(row)
        id_to_record[rec['id']] = rec

    alphas = []
    for aid in ids:
        rec = id_to_record.get(aid)
        if not rec:
            return jsonify({'error': f'Alpha ID {aid} 不存在'}), 404
        m = rec.get('metrics', {})
        alphas.append({
            'id': rec['id'],
            'name': rec.get('name', rec['expression'][:40]),
            'expression': rec['expression'],
            'type': rec.get('type', 'alpha'),
            'timestamp': rec.get('timestamp', ''),
            'metrics': {
                'pearson_ic': m.get('pearson_ic'),
                'annual_excess': m.get('annual_excess'),
                'sharpe': m.get('sharpe'),
                'fitness': m.get('fitness'),
                'turnover': m.get('turnover'),
                'max_drawdown': m.get('max_drawdown'),
                'margin_bps': m.get('margin_bps'),
                'win_rate': m.get('win_rate'),
                'rank_ic': m.get('rank_ic'),
                'icir': m.get('icir'),
                'sortino': m.get('sortino'),
            },
            'pnl_series': rec.get('pnl_series', []),
            'ic_series': rec.get('ic_series', []),
        })

    return jsonify({'success': True, 'alphas': alphas})


@app.route('/api/alpha/correlation', methods=['POST'])
def api_alpha_correlation():
    """Compute pairwise correlation matrix of daily excess returns for 3-10 alphas.

    Accepts: {"ids": ["id1","id2",...]}  (3-10 IDs)
    Returns: alphas metadata, daily_pnl (differenced from cumulative),
             ic_series, correlation_matrix.
    """
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401

    data = request.get_json()
    ids = data.get('ids', [])

    if not ids or len(ids) < 3:
        return jsonify({'error': '至少需要选择3个Alpha'}), 400
    if len(ids) > 10:
        return jsonify({'error': '最多选择10个Alpha'}), 400

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    placeholders = ','.join(['?' for _ in ids])
    rows = conn.execute(
        f'SELECT * FROM alpha_history WHERE id IN ({placeholders})', ids
    ).fetchall()
    conn.close()

    id_to_record = {}
    for row in rows:
        rec = _row_to_record(row, include_pnl=True)
        id_to_record[rec['id']] = rec

    alphas = []
    daily_pnls = []  # list of 1D np arrays (daily excess returns, not cumulative)

    for aid in ids:
        rec = id_to_record.get(aid)
        if not rec:
            return jsonify({'error': f'Alpha ID {aid} 不存在'}), 404
        m = rec.get('metrics', {})
        cum_pnl = rec.get('pnl_series', [])
        # Difference cumulative PnL to get daily excess returns (%)
        # cum_pnl stores cumulative % (cum * 100), so diff gives daily bp changes / 100 = daily excess return in %
        dailies = np.array([cum_pnl[i] - cum_pnl[i - 1] for i in range(1, len(cum_pnl))]) if len(cum_pnl) > 1 else np.array([])
        daily_pnls.append(dailies)
        alphas.append({
            'id': rec['id'],
            'name': rec.get('name', rec['expression'][:40]),
            'expression': rec['expression'],
            'type': rec.get('type', 'alpha'),
            'metrics': {
                'pearson_ic': m.get('pearson_ic'),
                'annual_excess': m.get('annual_excess'),
                'sharpe': m.get('sharpe'),
                'fitness': m.get('fitness'),
                'turnover': m.get('turnover'),
                'max_drawdown': m.get('max_drawdown'),
                'margin_bps': m.get('margin_bps'),
                'win_rate': m.get('win_rate'),
            },
            'pnl_series': rec.get('pnl_series', []),
            'ic_series': rec.get('ic_series', []),
        })

    # Compute pairwise correlation matrix from daily excess returns
    n = len(alphas)
    corr_matrix = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            if i == j:
                corr_matrix[i][j] = 1.0
            else:
                a = daily_pnls[i]
                b = daily_pnls[j]
                # Align to common length
                min_len = min(len(a), len(b))
                if min_len < 10:
                    corr_matrix[i][j] = 0.0
                    continue
                aa = a[-min_len:]
                bb = b[-min_len:]
                # Remove NaNs / Infs
                mask = np.isfinite(aa) & np.isfinite(bb)
                if mask.sum() < 10:
                    corr_matrix[i][j] = 0.0
                else:
                    corr_matrix[i][j] = round(float(np.corrcoef(aa[mask], bb[mask])[0, 1]), 4)

    # Find most and least correlated pair
    max_corr = -2.0
    min_corr = 2.0
    max_pair = None
    min_pair = None
    for i in range(n):
        for j in range(i + 1, n):
            c = corr_matrix[i][j]
            if c > max_corr:
                max_corr = c
                max_pair = (alphas[i]['name'], alphas[j]['name'], c)
            if c < min_corr:
                min_corr = c
                min_pair = (alphas[i]['name'], alphas[j]['name'], c)

    return jsonify({
        'success': True,
        'alphas': alphas,
        'corr_matrix': corr_matrix.tolist(),
        'summary': {
            'max_pair': list(max_pair) if max_pair else None,
            'min_pair': list(min_pair) if min_pair else None,
        },
    })


@app.route('/api/alpha/decay', methods=['POST'])
def api_alpha_decay():
    """Compute IC Persistence (IC series autocorrelation at lags) for 3-10 alphas.

    IMPORTANT: This is NOT WQ-style IC Decay (factor[t] vs label[t+lag]).
    Since raw factor arrays are too large to store, we use the stored IC series
    as an approximation. This measures "IC Persistence" — the autocorrelation of
    the daily IC sequence at lags [1, 3, 5, 10, 15, 20] — which captures how
    persistently the factor's predictive power holds over time.

    Accepts: {"ids": ["id1","id2",...]}
    """
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401

    data = request.get_json()
    ids = data.get('ids', [])

    if not ids or len(ids) < 3:
        return jsonify({'error': '至少需要选择3个Alpha'}), 400
    if len(ids) > 10:
        return jsonify({'error': '最多选择10个Alpha'}), 400

    lags = [1, 3, 5, 10, 15, 20]

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    placeholders = ','.join(['?' for _ in ids])
    rows = conn.execute(
        f'SELECT * FROM alpha_history WHERE id IN ({placeholders})', ids
    ).fetchall()
    conn.close()

    id_to_record = {}
    for row in rows:
        rec = _row_to_record(row)
        id_to_record[rec['id']] = rec

    decay_results = []
    for aid in ids:
        rec = id_to_record.get(aid)
        if not rec:
            return jsonify({'error': f'Alpha ID {aid} 不存在'}), 404

        ic_raw = rec.get('ic_series', [])
        # ic_series is stored as list of floats (or None for NaN)
        ic_arr = np.array([x if x is not None else np.nan for x in ic_raw], dtype=np.float64)
        # Remove NaN values
        ic_clean = ic_arr[np.isfinite(ic_arr)]

        decay = {}
        for lag in lags:
            if len(ic_clean) > lag + 10:
                a = ic_clean[lag:]
                b = ic_clean[:-lag]
                mask = np.isfinite(a) & np.isfinite(b)
                if mask.sum() >= 10:
                    decay[str(lag)] = round(float(np.corrcoef(a[mask], b[mask])[0, 1]), 4)
                else:
                    decay[str(lag)] = None
            else:
                decay[str(lag)] = None

        decay_results.append({
            'id': rec['id'],
            'name': rec.get('name', rec['expression'][:40]),
            'persistence': decay,
        })

    return jsonify({
        'success': True,
        'lags': lags,
        'decay_results': decay_results,
        'note': 'IC Persistence (IC时序自相关): 近似度量，因子原始数组未存储，使用已保存的IC序列计算自相关。测量的是IC自身的持续性，而非因子值与未来收益的相关性。',
    })


@app.route('/api/alpha/selfcorr', methods=['POST'])
def api_alpha_selfcorr():
    """Compute IC Self-Correlation (lag-1 IC autocorrelation) for 1-50 alphas.

    WQ requires self_corr < 0.6 for submission. Since raw factor arrays are not
    stored (too large), this uses the stored IC series as an approximation.
    True factor self-correlation (factor[t] vs factor[t+1]) would correlate the
    raw factor values across adjacent days, but we approximate it using the IC
    series lag-1 autocorrelation instead.

    Accepts: {"ids": ["id1","id2",...]}
    Returns: [{id, name, self_corr, status ("PASS"/"FAIL")}]
    """
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401

    data = request.get_json()
    ids = data.get('ids', [])

    if not ids or len(ids) < 1:
        return jsonify({'error': '至少需要选择1个Alpha'}), 400
    if len(ids) > 50:
        return jsonify({'error': '最多选择50个Alpha'}), 400

    THRESHOLD = 0.6
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    placeholders = ','.join(['?' for _ in ids])
    rows = conn.execute(
        f'SELECT * FROM alpha_history WHERE id IN ({placeholders})', ids
    ).fetchall()
    conn.close()

    id_to_record = {}
    for row in rows:
        rec = _row_to_record(row)
        id_to_record[rec['id']] = rec

    results = []
    for aid in ids:
        rec = id_to_record.get(aid)
        if not rec:
            return jsonify({'error': f'Alpha ID {aid} 不存在'}), 404

        ic_raw = rec.get('ic_series', [])
        ic_arr = np.array([x if x is not None else np.nan for x in ic_raw], dtype=np.float64)
        ic_clean = ic_arr[np.isfinite(ic_arr)]

        if len(ic_clean) > 11:
            a = ic_clean[1:]
            b = ic_clean[:-1]
            mask = np.isfinite(a) & np.isfinite(b)
            if mask.sum() >= 10:
                lag1_corr = round(float(np.corrcoef(a[mask], b[mask])[0, 1]), 4)
            else:
                lag1_corr = None
        else:
            lag1_corr = None

        m = rec.get('metrics', {})
        results.append({
            'id': rec['id'],
            'name': rec.get('name', rec['expression'][:40]),
            'expression': rec['expression'],
            'self_corr': lag1_corr,
            'status': 'PASS' if lag1_corr is not None and abs(lag1_corr) < THRESHOLD else 'FAIL',
            'sharpe': m.get('sharpe'),
            'pearson_ic': m.get('pearson_ic'),
        })

    return jsonify({
        'success': True,
        'threshold': THRESHOLD,
        'results': results,
        'note': 'IC Self-Correlation (近似): 使用IC序列的lag-1自相关近似因子自相关。WQ要求 self_corr < 0.6 方可提交。',
    })


@app.route('/api/alpha/history/dedup', methods=['POST'])
def api_alpha_history_dedup():
    """Deduplicate alpha history — keep only the best entry per unique expression."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        'SELECT id, expression, metrics_json FROM alpha_history ORDER BY timestamp DESC'
    ).fetchall()
    conn.close()
    # Group by expression, keep only the BEST (highest Sharpe+Fitness) per expression
    seen = {}
    to_delete = []
    for row in rows:
        expr = row['expression'].strip()
        if expr in seen:
            to_delete.append(row['id'])
        else:
            seen[expr] = row['id']
    if not to_delete:
        return jsonify({'success': True, 'deleted': 0, 'kept': len(seen), 'message': '没有重复因子'})
    conn = sqlite3.connect(DB_PATH)
    for rid in to_delete:
        conn.execute('DELETE FROM alpha_history WHERE id=?', (rid,))
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'deleted': len(to_delete), 'kept': len(seen)})


@app.route('/api/alpha/history/clear', methods=['POST'])
def api_alpha_history_clear():
    """Clear all alpha history."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401

    conn = sqlite3.connect(DB_PATH)
    count = conn.execute('SELECT COUNT(*) FROM alpha_history').fetchone()[0]
    conn.execute('DELETE FROM alpha_history')
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'cleared': count})


# ---- Community Forum (SQLite-backed) ----

@app.route('/learn')
def learn_page():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('learn.html')


@app.route('/community')
def community_page():
    if 'user' not in session:
        return redirect(url_for('login'))
    raw_user = session['user']
    display_name = _resolve_display_name(raw_user)
    return render_template('community.html', username=display_name, is_admin=(raw_user=='admin'))


@app.route('/api/community/posts', methods=['GET'])
def api_community_get_posts():
    """Return all community posts (newest first), with alpha_ref when alpha_id is set."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        'SELECT p.*, a.expression AS ref_expr, a.metrics_json AS ref_metrics, a.pnl_json AS ref_pnl '
        'FROM community_posts p '
        'LEFT JOIN alpha_history a ON p.alpha_id = a.id '
        'ORDER BY p.timestamp DESC'
    ).fetchall()
    # Get likes for current user
    user_email = session.get('user', '')
    liked_rows = conn.execute('SELECT post_id FROM post_likes WHERE user_email=?',
                              (user_email,)).fetchall()
    liked_set = {r['post_id'] for r in liked_rows}
    conn.close()

    posts = []
    for row in rows:
        post = _build_post_dict(dict(row))
        post['likes'] = row['likes'] or 0
        post['liked_by_me'] = row['id'] in liked_set
        # Admin badge
        post['is_admin'] = (row['author'] == 'admin')
        posts.append(post)
    return jsonify({'count': len(posts), 'posts': posts})


@app.route('/api/community/posts', methods=['POST'])
def api_community_create_post():
    """Create a new community post. Accepts optional alpha_id to reference an alpha."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401

    data = request.get_json()
    if not data:
        return jsonify({'error': '请求体为空'}), 400

    expression = (data.get('expression', '') or '').strip()
    if not expression:
        return jsonify({'error': '表达式不能为空'}), 400

    name = (data.get('name', '') or '').strip()
    description = (data.get('description', '') or '').strip()
    alpha_id = (data.get('alpha_id', '') or '').strip()

    raw_user = session['user']

    # Validate alpha_id if provided
    if alpha_id:
        conn = sqlite3.connect(DB_PATH)
        exists = conn.execute('SELECT 1 FROM alpha_history WHERE id=?', (alpha_id,)).fetchone()
        conn.close()
        if not exists:
            return jsonify({'error': '引用的 Alpha 不存在'}), 400

    # Resolve display name: look up nickname from users table
    display_name = _resolve_display_name(raw_user)

    post_id = str(uuid.uuid4())
    timestamp = datetime.datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
    post_name = name or expression[:40] + ('...' if len(expression) > 40 else '')

    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        'INSERT INTO community_posts (id, author, expression, name, description, timestamp, alpha_id) '
        'VALUES (?, ?, ?, ?, ?, ?, ?)',
        (post_id, raw_user, expression, post_name, description, timestamp, alpha_id or None)
    )
    conn.commit()
    conn.close()

    post = {
        'id': post_id,
        'author': raw_user,
        'author_display': display_name,
        'expression': expression,
        'name': post_name,
        'description': description,
        'timestamp': timestamp,
        'alpha_id': alpha_id or None,
    }
    return jsonify({'success': True, 'post': post})


@app.route('/api/community/posts/<post_id>', methods=['DELETE'])
def api_community_delete_post(post_id):
    """Delete a community post (admin only)."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401
    if session['user'] != 'admin':
        return jsonify({'error': '仅管理员可删除'}), 403
    conn = sqlite3.connect(DB_PATH)
    conn.execute('DELETE FROM community_posts WHERE id=?', (post_id,))
    conn.commit()
    conn.close()
    return jsonify({'success': True})


@app.route('/api/community/posts/<post_id>/like', methods=['POST'])
def api_community_like(post_id):
    """Toggle like on a post."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401
    user_email = session['user']
    conn = sqlite3.connect(DB_PATH)
    existing = conn.execute('SELECT 1 FROM post_likes WHERE post_id=? AND user_email=?',
                            (post_id, user_email)).fetchone()
    if existing:
        conn.execute('DELETE FROM post_likes WHERE post_id=? AND user_email=?',
                     (post_id, user_email))
        conn.execute('UPDATE community_posts SET likes=MAX(0, likes-1) WHERE id=?', (post_id,))
        conn.commit()
        likes = conn.execute('SELECT likes FROM community_posts WHERE id=?', (post_id,)).fetchone()
        conn.close()
        return jsonify({'liked': False, 'likes': likes[0] if likes else 0})
    else:
        conn.execute('INSERT INTO post_likes(post_id, user_email) VALUES(?,?)',
                     (post_id, user_email))
        conn.execute('UPDATE community_posts SET likes=likes+1 WHERE id=?', (post_id,))
        conn.commit()
        likes = conn.execute('SELECT likes FROM community_posts WHERE id=?', (post_id,)).fetchone()
        conn.close()
        return jsonify({'liked': True, 'likes': likes[0] if likes else 0})


@app.route('/api/community/posts/<post_id>/comments', methods=['GET'])
def api_community_get_comments(post_id):
    """Get comments for a post."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        'SELECT * FROM post_comments WHERE post_id=? ORDER BY timestamp ASC',
        (post_id,)
    ).fetchall()
    conn.close()
    comments = []
    for row in rows:
        c = dict(row)
        c['author_display'] = _resolve_display_name(c.get('author', ''))
        c['is_admin'] = (c.get('author', '') == 'admin')
        comments.append(c)
    return jsonify({'comments': comments})


@app.route('/api/community/posts/<post_id>/comments', methods=['POST'])
def api_community_create_comment(post_id):
    """Add a comment to a post."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401
    data = request.get_json()
    content = (data.get('content', '') or '').strip()
    if not content:
        return jsonify({'error': '评论内容不能为空'}), 400
    if len(content) > 1000:
        return jsonify({'error': '评论不超过1000字'}), 400
    comment_id = str(uuid.uuid4())
    timestamp = datetime.datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
    user_email = session['user']
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        'INSERT INTO post_comments(id, post_id, author, content, timestamp) VALUES(?,?,?,?,?)',
        (comment_id, post_id, user_email, content, timestamp)
    )
    conn.commit()
    conn.close()
    return jsonify({
        'id': comment_id,
        'post_id': post_id,
        'author': user_email,
        'author_display': _resolve_display_name(user_email),
        'is_admin': (user_email == 'admin'),
        'content': content,
        'timestamp': timestamp,
    })


# ======================== MAIN ========================

# AI conversation memory (in-memory, per user session)
_ai_memory = {}

@app.route('/api/superalpha/lgb', methods=['POST'])
def api_superalpha_lgb():
    """LightGBM SuperAlpha: train LGB model on multiple factors and return combined metrics."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401
    data = request.get_json()
    expressions = [e.strip() for e in (data.get('expressions', []) or []) if e.strip()]
    if len(expressions) < 1:
        return jsonify({'error': '至少需要1个表达式'}), 400
    if len(expressions) > 50:
        return jsonify({'error': '最多50个表达式'}), 400
    try:
        pipeline, engine, fc = get_engine()
        t0 = pipeline.date_to_idx['2020-01-02']
        t1 = min(pipeline.date_to_idx['2023-12-29'] + 1, pipeline.n_dates)
        label_all = pipeline.fields['Label'][t0:t1]
        univ_all = pipeline.universe_mask[t0:t1]
        # Parse all factors
        factor_arrays = []
        for expr in expressions:
            f = parse_expression(expr, pipeline, fc)[t0:t1]
            factor_arrays.append(f)
        n_dates, n_stocks = factor_arrays[0].shape
        # Build flat feature matrix (impute NaN with 0)
        features = []
        for fa in factor_arrays:
            f_flat = fa.reshape(-1).copy()
            f_flat[np.isnan(f_flat)] = 0.0
            features.append(f_flat.reshape(-1, 1))
        X = np.hstack(features)
        y = label_all.reshape(-1).copy()
        y[np.isnan(y)] = 0.0
        y_orig = label_all.reshape(-1)
        valid_mask = np.logical_not(np.isnan(y_orig))
        if valid_mask.sum() < 1000:
            return jsonify({'error': '有效样本不足'}), 400
        X_train = X[valid_mask]
        y_train = y[valid_mask]
        # Train LightGBM on ALL data
        import lightgbm as lgb
        model = lgb.LGBMRegressor(
            n_estimators=100, max_depth=2, num_leaves=7,
            min_child_samples=2000, subsample=0.7, reg_alpha=1.0,
            reg_lambda=1.0, random_state=42, verbose=-1
        )
        model.fit(X_train, y_train)
        # Predict on ALL data
        pred_all = np.full(n_dates * n_stocks, np.nan)
        pred_all[valid_mask] = model.predict(X_train)
        pred_daily = pred_all.reshape(n_dates, n_stocks)
        # Evaluate on all data
        result = engine.full_evaluation(pred_daily, univ_all, label=label_all)
        metrics = _compute_metrics_from_result(pred_daily, label_all, univ_all, result)
        display_keys = ['pearson_ic','rank_ic','icir','ic_positive_ratio',
            'annual_excess','sharpe','fitness','returns','max_drawdown',
            'turnover','margin_bps','sortino','win_rate','n_days',
            'ic_series','pnl_series']
        metrics_clean = {k: v for k, v in metrics.items() if k in display_keys}
        # Save to history
        combined_expression = 'lgb(' + ', '.join(expressions) + ')'
        _add_to_history(combined_expression, metrics_clean, 'superalpha')
        # Evaluate each sub-factor individually for PnL overlay
        sub_alphas = []
        for i, expr in enumerate(expressions):
            sub_result = engine.full_evaluation(factor_arrays[i], univ_all, label=label_all)
            sub_metrics = _compute_metrics_from_result(factor_arrays[i], label_all, univ_all, sub_result)
            sub_alphas.append({
                'expression': expr,
                'metrics': {k: v for k, v in sub_metrics.items()
                           if k not in ('_factor_array', '_direction', 'ic_series')},
                'pnl_series': sub_metrics.get('pnl_series', []),
                'ic_series': sub_metrics.get('ic_series', []),
            })
        return jsonify({
            'success': True,
            'type': 'lgb_superalpha',
            'n_factors': len(expressions),
            'n_samples': int(valid_mask.sum()),
            'feature_importance': dict(zip(expressions, model.feature_importances_.tolist())),
            'metrics': metrics_clean,
            'combined_metrics': metrics_clean,
            'pnl_series': metrics.get('pnl_series', []),
            'sub_alphas': sub_alphas,
        })
    except Exception as e:
        import traceback; traceback.print_exc()
        return jsonify({'error': f'LightGBM训练失败: {str(e)}'}), 400


@app.route('/api/ai/ask', methods=['POST'])
def api_ai_ask():
    """Platform AI: answer questions by reading source code."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401
    data = request.get_json()
    question = (data.get('question', '') or '').strip()
    if not question:
        return jsonify({'error': '问题不能为空'}), 400

    # Load key source code sections
    base = os.path.dirname(__file__)
    app_path = os.path.join(base, 'app.py')
    ep_path = os.path.join(base, 'expression_parser.py')

    code_context = ''
    if os.path.exists(app_path):
        with open(app_path, 'r', encoding='utf-8') as f:
            app_code = f.read()
        # Include: LGB endpoint, SA endpoint, backtest, metrics, _add_to_history
        sections = []
        for marker in ['def api_superalpha_lgb', 'def api_superalpha', 'def api_backtest_legacy',
                        'def _compute_metrics_from_result', 'def _add_to_history',
                        'def api_alpha_history', 'def api_community',
                        'def api_ai_ask', 'def _init_db', 'def get_engine']:
            idx = app_code.find(marker)
            if idx >= 0:
                end = app_code.find('\ndef ', idx + 10)
                if end < 0: end = len(app_code)
                sections.append(app_code[max(0,idx-20):min(len(app_code),end+200)])
        code_context += '\n=== app.py 关键函数 ===\n' + '\n...\n'.join(sections[-8:])

    if os.path.exists(ep_path):
        with open(ep_path, 'r', encoding='utf-8') as f:
            ep_code = f.read()
        # Include: parse_expression, _parse_single, _eval_function, field registries
        idx = ep_code.find('def parse_expression')
        if idx >= 0:
            code_context += '\n=== expression_parser.py ===\n' + ep_code[idx:idx+3000]

    # Load complete field list
    from expression_parser import FIELDS_METADATA, DERIVED_FIELD_REGISTRY
    field_list = []
    for name, meta in sorted(FIELDS_METADATA.items()):
        cn = meta.get('chinese_name', name)
        field_list.append(f"  {name} ({cn}) — {meta.get('description','')[:60]}")
    fields_text = '\n'.join(field_list)

    system_prompt = f'''你是"量化回测平台"的AI助手，运行在DeepSeek API上。只能回答平台相关问题，基于下方提供的源码和字段列表精确回答。

平台功能：
- POST /api/backtest — 表达式回测(IC/Sharpe/Fitness/PnL)
- POST /api/superalpha — 等权组合(zscore标准化→等权平均→回测)
- POST /api/superalpha/lgb — LightGBM训练(表达式→LGB全量训练→IC/PnL/特征重要性)
- GET /api/alpha/history — 回测历史
- 89个数据字段(下方完整列表)
- 操作符: rank, zscore, ts_delta, ts_mean, ts_std, ts_rank, ts_sum, ts_corr, ts_decay_linear, ts_delay, ts_backfill, ts_regression, ts_argmax, ts_argmin, signed_power, group_neutralize, group_rank, group_zscore, demean, log, exp, sqrt, abs, sign, power, if_else
- 多行代码: 分号/换行分隔, 变量赋值(如 returns=close/open-1; returns+1)
- 市值中性化: POST时指定neutralize=market_cap

回答规则：严格基于下方源码和字段列表。不知道就说不知道。引用行号。200字以内。

=== 全部可用字段 ===
{fields_text}

=== 平台源码 ===
{code_context}'''

    # Conversation memory
    user = session.get('user', 'guest')
    if user not in _ai_memory:
        _ai_memory[user] = []
    history = _ai_memory[user]

    # Build messages: system + history + current question
    messages = [{'role': 'system', 'content': system_prompt}]
    messages.extend(history[-20:])  # last 10 rounds (20 messages)
    messages.append({'role': 'user', 'content': question})

    try:
        resp = requests.post(
            'https://api.deepseek.com/v1/chat/completions',
            headers={'Authorization': f'Bearer {os.environ.get("DEEPSEEK_API_KEY", "")}', 'Content-Type': 'application/json'},
            json={'model': 'deepseek-chat', 'messages': messages, 'max_tokens': 800, 'temperature': 0.3},
            timeout=25
        )
        if resp.status_code == 200:
            answer = resp.json()['choices'][0]['message']['content']
        else:
            answer = f'API错误({resp.status_code})'
    except Exception as e:
        answer = f'请求失败: {str(e)}'

    # Save to history
    history.append({'role': 'user', 'content': question})
    history.append({'role': 'assistant', 'content': answer})
    if len(history) > 40:
        history = history[-40:]
    _ai_memory[user] = history

    return jsonify({'question': question, 'answer': answer})


@app.route('/api/alpha/recompute_max_corr', methods=['POST'])
def api_recompute_max_corr():
    """Recompute max pairwise correlation for all single-alpha factors.

    Computes daily excess returns from stored PnL series, then for each alpha
    finds the maximum correlation with any other alpha. LGB/superalpha combos
    are excluded (they're composites of other factors).

    Returns {updated: N, total: M}."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT id, expression, type, pnl_json FROM alpha_history"
    ).fetchall()
    conn.close()

    # Filter to single-alphas only (exclude superalpha/LGB combos)
    singles = []
    for row in rows:
        t = row['type'] or 'alpha'
        expr = row['expression'] or ''
        if t == 'superalpha' or expr.startswith('lgb(') or expr.startswith('superalpha('):
            continue
        try:
            pnl_raw = json.loads(row['pnl_json'] or '[]')
        except Exception:
            continue
        if len(pnl_raw) < 20:
            continue
        # Cumulative PnL -> daily excess returns
        dailies = np.array([pnl_raw[i] - pnl_raw[i - 1] for i in range(1, len(pnl_raw))])
        # Remove NaN/Inf
        dailies = dailies[np.isfinite(dailies)]
        if len(dailies) < 20:
            continue
        singles.append((row['id'], dailies))

    if len(singles) < 2:
        return jsonify({'error': '至少需要2个单因子', 'total': len(singles)}), 400

    n = len(singles)
    max_corrs = {sid: 0.0 for sid, _ in singles}

    for i in range(n):
        id_i, di = singles[i]
        for j in range(i + 1, n):
            id_j, dj = singles[j]
            min_len = min(len(di), len(dj))
            if min_len < 10:
                continue
            a = di[-min_len:]
            b = dj[-min_len:]
            mask = np.isfinite(a) & np.isfinite(b)
            if mask.sum() < 10:
                continue
            c = abs(float(np.corrcoef(a[mask], b[mask])[0, 1]))
            if not np.isfinite(c):
                continue
            if c > max_corrs[id_i]:
                max_corrs[id_i] = c
            if c > max_corrs[id_j]:
                max_corrs[id_j] = c

    # Update DB
    conn = sqlite3.connect(DB_PATH)
    updated = 0
    for sid, mc in max_corrs.items():
        conn.execute('UPDATE alpha_history SET max_corr=? WHERE id=?',
                     (round(float(mc), 4), sid))
        updated += 1
    conn.commit()
    conn.close()

    return jsonify({'success': True, 'updated': updated, 'total': len(singles)})


@app.route('/api/ai/clear', methods=['POST'])
def api_ai_clear():
    """Clear conversation memory."""
    if 'user' not in session:
        return jsonify({'error': '未登录'}), 401
    user = session.get('user', 'guest')
    _ai_memory.pop(user, None)
    return jsonify({'success': True})


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True, use_reloader=False)
