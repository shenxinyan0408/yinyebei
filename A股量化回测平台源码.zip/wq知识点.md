# WorldQuant 因子构建完全知识体系

> 整合自 52 篇 WQ 知识文档、论坛讨论、学术论文及实战经验
> 涵盖平台操作、因子构建、高 Sharpe 模式、中性化、IQC 竞赛、优化调参、常见陷阱

---

## 一、WQ 平台概述

### 1.1 平台是什么

WorldQuant BRAIN (platform.worldquantbrain.com) 是一个量化金融研究平台，核心功能：
- 用 **FASTEXPR 表达式语言**编写 Alpha 策略（量化交易信号）
- 通过**历史回测（Simulation）**验证 Alpha 表现
- 参加 **IQC 国际量化锦标赛**等竞赛
- 成为 **Consultant** 获取实盘交易收入分成
- 访问 **8 大类别、数千个数据字段**

> 来源: WQ_BRAIN_PLATFORM_GUIDE.md

### 1.2 核心概念

| 概念 | 说明 |
|------|------|
| Alpha | 用 FASTEXPR 编写的量化交易信号公式 |
| Simulation | 对 Alpha 进行历史回测 |
| Sharpe / Fitness / Turnover / Margin | 评估 Alpha 质量的核心四大指标 |
| Neutralization | 中性化处理（移除市场、行业等系统性偏差） |
| COMBO | 所有已提交 Alpha 的等权组合 |
| Delay | 数据延迟：D0=当天收盘, D1=次日开盘 |
| Sub-Universe | 子宇宙，检测 Alpha 在不同子集上的稳定性 |

### 1.3 用户等级

Bronze -> Silver -> Gold -> Platinum -> Expert -> Master -> Grandmaster

- 10,000 分可申请 Consultant
- Expert+ 解锁高级操作符（vector_neut, regression_neut）
- Master(10K+) 解锁 vector_neut

> 来源: WQ_BRAIN_PLATFORM_GUIDE.md, WQ_CONSULTANT_GUIDE.md

### 1.4 Consultant 报酬

| 类型 | 范围 | 条件 |
|------|------|------|
| 日结基础报酬 | $1-$60/天 (Regular) + $1-$60/天 (Super) | 持续提交 |
| 季度奖金 | $100-$25,000/季度 | 上季度至少提交 20 天 |
| 推荐奖金 | $200/人 | 被推荐人成为顾问并活跃 |

> 来源: WQ_CONSULTANT_GUIDE.md

---

## 二、因子构建方法论

### 2.1 Alpha 表达式结构

```
<group_op>(<ts_op>(<field>, <days>), <group>)
```

**核心构建公式：**
```
group_neutralize(ts_rank(ts_delta(close, 5), 120), subindustry)
```

> 来源: WQ_HIGH_SHARPE_PATTERNS.md

### 2.2 核心四大指标

| 指标 | 公式 | 合格线 | 优秀线 |
|------|------|--------|--------|
| **Sharpe** | sqrt(252) x Mean(PnL)/Std(PnL) | >=1.25(D1), >=2.0(D0) | >2.0 |
| **Fitness** | Sharpe x sqrt(|Returns|/max(Turnover,0.125)) | >=1.0 | >1.5 |
| **Turnover** | DollarTradingValue/BookSize | 5%-70% | ~12.5% |
| **Returns** | Annualized PnL/(0.5xBookSize) | >5% | >15% |

**关键洞察：** Turnover 低于 0.125 时在 Fitness 分母中被锁定为 0.125，继续降低无额外收益。目标 Turnover ~12.5% 以最大化 Fitness。

> 来源: WQ_SIMULATION_METRICS_GUIDE.md, WQ_ALPHA_OPTIMIZATION_HANDBOOK.md

### 2.3 操作符分类速查

#### 时间序列操作符（最常用）

| 操作符 | 用途 | 示例 |
|--------|------|------|
| `ts_delta(x, d)` | d天变化 | `ts_delta(close, 5)` |
| `ts_mean(x, d)` | d天均值 | `ts_mean(volume, 20)` |
| `ts_rank(x, d)` | d天内排名 | `ts_rank(returns, 20)` |
| `ts_zscore(x, d)` | d天z-score | `ts_zscore(close, 60)` |
| `ts_std(x, d)` | d天标准差 | `ts_std(returns, 60)` |
| `ts_corr(x, y, d)` | 滚动相关（仅时序） | `ts_corr(close, volume, 20)` |
| `ts_decay_linear(x, d)` | 线性衰减加权 | `ts_decay_linear(returns, 5)` |
| `ts_backfill(x, n)` | 前向填充NaN | `ts_backfill(field, 120)` |
| `ts_arg_max(x, d)` | 最大值距今几天 | `ts_arg_max(volume, 5)` |

#### 横截面操作符

| 操作符 | 用途 | 示例 |
|--------|------|------|
| `rank(x)` | 0-1 百分位排名（最重要） | `rank(ts_delta(close, 5))` |
| `zscore(x)` | 截面标准化 | `zscore(returns)` |
| `winsorize(x, std=4)` | 缩尾处理 | `winsorize(field, 4)` |
| `quantile(x, "gaussian")` | 分布重塑 | `quantile(alpha, "gaussian")` |

#### 分组操作符（中性化核心）

| 操作符 | 用途 |
|--------|------|
| `group_neutralize(x, group)` | 组内中性化（减组均值） |
| `group_rank(x, group)` | 组内排名 |
| `group_zscore(x, group)` | 组内标准化 |
| `group_backfill(x, d, group)` | 组内填充缺失值 |

#### 条件/控制操作符

| 操作符 | 用途 |
|--------|------|
| `trade_when(cond, alpha, fallback)` | 条件交易（降换手核心） |
| `if_else(cond, a, b)` | 条件选择 |
| `hump(x, threshold)` | 变化超阈值才更新信号 |
| `signed_power(x, n)` | 保持符号的幂函数 |
| `bucket(rank(x), "0,1,0.1")` | 分桶/自定义分组 |

**特殊操作符：**
- `vector_neut(X, Y)`: 移除 X 在 Y 上的投影（需 Master 级别）
- `ts_target_tvr_hump(x, 0, 1, 0.1)`: 动态调整信号至目标换手率
- `densify(group)`: 分组重索引提升计算效率

> 来源: WQ_OPERATORS_ENCYCLOPEDIA.md, WQ_FASTEXPR_LANGUAGE_GUIDE.md, WQ_BRAIN_PLATFORM_GUIDE.md

### 2.4 字段预处理标准（永远第一步）

```
winsorize(ts_backfill(field, 120), std=4)
```

向量字段先聚合：
```
vec_avg(field)  或  vec_sum(field)
```

> 来源: WQ_ROBUSTNESS_OVERFITTING.md, WQ_FASTEXPR_LANGUAGE_GUIDE.md

### 2.5 标准回溯窗口

| 窗口 | 适用场景 |
|------|---------|
| 5天 | 短期反转/动量 |
| 22天 | 月度周期 |
| 60天 | 季度周期 |
| 120天 | 半年 |
| 240天 | 年度 |
| 252天 | 交易年 |

**严格避免非标准窗口**（如 37, 83 天）-- 这是过拟合的标志。

> 来源: WQ_FASTEXPR_LANGUAGE_GUIDE.md, WQ_ALPHA_MASTER_CLASS.md

### 2.6 操作符数量限制

- 每个 alpha 限制 <= 5 个操作符（重复算一个）
- 过多操作符 -> 过拟合风险高
- 简洁表达式 -> 泛化能力强

> 来源: WQ_OPERATORS_ENCYCLOPEDIA.md

### 2.7 rank(-A) vs -rank(A)

- `rank(-A)`: 先取反再排名，排名顺序完全反转 -> 值范围 [0,1]
- `-rank(A)`: 先排名再取负 -> 值范围 [-1,0]

隔离时指标相同，但与 `if_else()` 配合时行为不同。中性化后差异可能被消除。

> 来源: WQ_OPERATORS_ENCYCLOPEDIA.md, WQ_NEUTRALIZATION_GUIDE.md

### 2.8 FASTEXPR 常见陷阱

| 陷阱 | 问题 | 修复 |
|------|------|------|
| `log(负数)` | 返回 NaN | `log(abs(x)+1)` |
| 除零 | `close/volume` 中 volume=0 | `close/(volume+1)` 或先 rank |
| 不同尺度相加 | `ts_delta(close,20) + volume` | `rank(A) + rank(B)` |
| 比较操作符返回布尔值 | `close > ts_mean(close,20)` 非信号 | 用 `if_else(cond, 1, -1)` 包裹 |

> 来源: WQ_FASTEXPR_LANGUAGE_GUIDE.md

### 2.9 FASTEXPR 形式化语法 (BNF)

```
<expression>     ::= <term> | <expression> <binop> <term>
<term>           ::= <unary> <atom> | <atom>
<atom>           ::= <literal> | <field> | <func_call> | "(" <expression> ")"
<literal>        ::= <number> | <number> "." <number>
<number>         ::= <digit>+ | "-" <digit>+
<field>          ::= <letter>+ ( "_" <letter>+ )*  // e.g. close, mdl175_volatility, fnd6_epsfx

<func_call>      ::= <func_name> "(" <arglist> ")"
<func_name>      ::= "rank" | "ts_delta" | "ts_mean" | "ts_std" | "ts_rank" | "ts_zscore"
                   | "ts_corr" | "ts_sum" | "ts_max" | "ts_min" | "ts_arg_max" | "ts_arg_min"
                   | "ts_decay_linear" | "ts_delay" | "ts_backfill" | "ts_regression"
                   | "signed_power" | "zscore" | "demean" | "winsorize" | "quantile"
                   | "group_neutralize" | "group_rank" | "group_zscore" | "group_backfill"
                   | "trade_when" | "if_else" | "hump" | "hump_decay" | "scale"
                   | "vec_avg" | "vec_sum" | "vec_max" | "vec_min" | "vec_count"
                   | "vector_neut" | "group_vector_neut" | "regression_neut"
                   | "bucket" | "densify" | "power" | "log" | "exp" | "sqrt" | "abs"
                   | "ts_target_tvr_hump"
<arglist>        ::= <expression> | <expression> "," <arglist>

<binop>          ::= "+" | "-" | "*" | "/" | "^"
<unary>          ::= "-" | "+"

<variable>       ::= <letter>+ "=" <expression>  // e.g. returns=close/open-1
<multi_line>     ::= (<variable> ";")* <expression>  // 分号分隔多行
```

**关键解析规则：**
- 空格和换行是分隔符，对语法无影响
- 函数参数从左到右求值，无短路逻辑
- `rank(-A)` 先取反再排名 | `-rank(A)` 先排名再取负
- 比较运算符 (`<`, `>`, `==`, `!=`, `>=`, `<=`, `AND`, `OR`) 仅用于 `trade_when`/`if_else` 条件
- 布尔值在数值上下文中：`true=1`, `false=0`
- `vec_*` 函数用于 VECTOR 类型字段，将每天多值聚合为单值

---

## 三、高 Sharpe 模式库

### 3.1 历史最高记录

| 区域 | Sharpe | 表达式 | 关键参数 |
|------|--------|--------|---------|
| **CHN** | **5.03** | `rank(-mdl175_volatility * log(volume)) * (1 + group_rank(mdl175_revenuettm, gp))` | Decay=3, Delay=0, 中性化=sector |
| **USA** | **2.58** | `-ts_zscore(enterprise_value/ebitda, 63)` | Decay=0, Delay=0, 中性化=subindustry |
| **USA** | **2.03** | `rank(ts_rank(fnd6_epsfx / close, 40))` | Decay=9, Top1000, 中性化=subindustry |

> 来源: WQ_HIGH_SHARPE_PATTERNS.md

### 3.2 八大高 Sharpe 模式

#### A. 价格反转（均值回归）

```
ts_rank(ts_delta(close,5) - ts_mean(close,5), 252)  // Sharpe>1.2
rank(ts_mean(close, 30) - close)                     // Sharpe~1.4-1.9
(high + low) / 2 - close                             // Sharpe 1.80
-ts_delta(close, 5)                                  // 最简单的5天反转
```

**最佳 Decay:** 2-5 | **灵敏度:** 高 | **最佳中性化:** SUBINDUSTRY
适用于所有市场，特别是高波动期。

#### B. 成交量-价格交互

```
rank(-mdl175_volatility * log(volume))                     // CHN 高 Sharpe
-1 * ts_corr(open, volume, 10)                         // 经典 101 Alpha
ts_corr(ts_rank(close, 22), ts_rank(volume, 22), 10)      // 成交量确认趋势
```

#### C. VWAP 回归

```
(vwap - close) / vwap                                     // 经典, Decay=15
ts_regression(close, vwap, 4, lag=0, rettype=2)           // Beta系数
```

**最佳 Decay:** 10-15 | **灵敏度:** 低 | VWAP信号稳定，高decay无妨。

#### D. 基本面比率（一致性最高）

```
rank(ts_rank(fnd6_epsfx / close, 40))           // Sharpe 2.03 - 盈利收益率
-rank(ebit / capex)                             // Sharpe 2.02 - 盈利能力
-ts_zscore(enterprise_value / ebitda, 63)       // Sharpe 2.58 - 价值因子
-ts_rank(retained_earnings, 500)                // Sharpe 1.55, 低换手3.71%
ts_rank(cashflow_op / cap, 60)                  // 经营盈利, Decay=4
```

**最佳 Decay:** 4-9 | **灵敏度:** 低 | 基本面数据更新慢，对decay不敏感。

#### E. 动量 + 反转混合

```
alpha = -sign(7d_price_change) * (1 + rank(250d_cumulative_return))
// 负号反转短期信号，长期动量调整
```

#### F. 多因子叠加

```
0.5 * rank(alpha_A) + 0.3 * rank(alpha_B) + 0.2 * rank(alpha_C)
```

#### G. 条件型（trade_when 模式）

```
// 低波动率过滤器
trade_when(ts_rank(ts_std(returns, 10), 252) < 0.9, alpha, -1)

// 高成交量过滤器
trade_when(volume > adv20, alpha, -1)

// 布林带突破
event = (close > ts_mean(close,20) + 2*ts_std(close,20)) OR
        (close < ts_mean(close,20) - 2*ts_std(close,20));
trade_when(event, -ts_delta(close, 5), 0)
```

#### H. 中国市场特有模式

**市值分层反转：**
```
group_rank(-ts_delta(close, 5), bucket(rank(cap), "0,1,0.2"))
```

**机构行为跟踪：**
```
rank(ts_delta(mdl175_inst_own, 22))
```

**涨停/跌停效应：**
```
rank(if_else(close == high, -1, if_else(close == low, 1, 0)))
```

> 来源: WQ_HIGH_SHARPE_PATTERNS.md

### 3.3 Alpha 模板工厂

**核心模板：**
```
<group_op>(<ts_op>(<field>, <days>), <group>)
```

**常用组合：**
```
group_ops  = {group_rank, group_zscore, group_neutralize}
ts_ops     = {ts_rank, ts_zscore, ts_delta, ts_delta, ts_mean}
days       = {5, 22, 60, 120, 240, 252}
groups     = {market, industry, subindustry, sector, gics_sector}
```

**一阶经典示例：**

| 表达式 | 逻辑 |
|--------|------|
| `ts_rank(ts_delta(close,5) - ts_mean(close,5), 252)` | 均值回归 |
| `(vwap - close) / vwap` | VWAP反转 |
| `rank(ts_mean(close,30) - close)` | 价格反转 |
| `ts_rank(cashflow_op / cap, 60)` | 经营盈利能力 |
| `-ts_zscore(enterprise_value/ebitda, 63)` | 价值因子 |

> 来源: WQ_HIGH_SHARPE_PATTERNS.md, WQ_ALPHA_PATTERN_LIBRARY.md

### 3.4 完整模式分类（8大类30+模板）

> 来源: WQ_ALPHA_PATTERN_LIBRARY.md

#### 动量模式

```
rank(ts_delta(close, 5))                                      # 时序动量
group_rank(ts_delta(close, 5), subindustry)                   # 截面动量
trade_when(volume > ts_mean(adv20, 20), ts_delta(close,5), 0) # 成交量确认动量
rank(-ts_rank(ts_delta(close, 1), 20))                        # RSI 动量
```

#### 反转模式

```
-ts_delta(close, 5)                                           # 短期反转
group_rank(-ts_delta(close, 5), subindustry)                  # 组内中性反转
rank(ts_mean(close, 30) - close)                              # 价格极端反转
rank(ts_zscore(close, 30))                                     # 标准化偏离
```

#### 价值模式

```
rank(fnd6_epsfx / close)                                      # 盈利收益率
group_rank(fnd6_epsfx / close, subindustry)                   # 组内价值
group_rank(fnd6_book_value / close, sector)                   # 账面市值比
rank(fnd6_cashflow_op / close)                                # 现金流收益率
```

#### 质量模式

```
group_rank(fnd6_return_on_equity, sector)                     # ROE质量
group_rank(-(fnd6_liabilities / fnd6_assets), subindustry)    # 低负债质量
group_rank(-ts_std(fnd6_epsfx, 8), subindustry)          # 盈利稳定性
```

#### 波动率模式

```
rank(-ts_std(returns, 60))                                # 低波异象
rank(-mdl175_volatility * log(volume))                        # 波动率+流动性(CHN 5.03)
trade_when(ts_rank(ts_std(returns,20),250) > 0.5, a, 0)  # 波动率体制过滤
```

#### 成交量/流动性模式

```
rank(volume / ts_mean(volume, 20))                            # 成交量异常
ts_corr(ts_rank(close, 22), ts_rank(volume, 22), 10)        # 价量相关性
rank(-ts_mean(abs(returns) / (volume/sharesout), 20))        # Amihud非流动性
```

#### 微观结构模式

```
rank((vwap - close) / vwap)                                   # VWAP回归
rank(close / open)                                            # 开盘-收盘
rank((high - low) / close)                                    # 日内价格范围
```

#### 多因子组合

```
rank(A) + rank(B) + rank(C)                                   # 线性加权
rank(A) * (1 + group_rank(B, subindustry))                    # 金字塔合成
vector_neut(rank(A), rank(B))                                 # 正交化组合
if_else(market_regime > 0, momentum_alpha, value_alpha)       # 条件多因子
```

### 3.5 市场环境-模式匹配

| 市场环境 | 推荐模式 | 数据集 |
|---------|---------|--------|
| 趋势市 | 动量 + 成交量确认 | pv1 |
| 震荡市 | 反转 + VWAP 回归 | pv1 |
| 高波动 | 低波 + 质量 | model77 + fundamental6 |
| 财报季 | 价值 + 分析师修正 | fundamental6 + analyst4 |
| 新闻密集 | 情绪 + 条件触发 | news12 + socialmedia12 |
| 不确定期 | 质量 + 低波组合 | fundamental6 + model77 |

---

## 四、中性化技术

### 4.1 中性化本质

移除 Alpha 信号中已知因子的暴露，使信号更"纯粹"。三大目标：
1. **提高独特性** -- 降低与已有 Alpha 的相关性
2. **提高稳定性** -- 移除市场/行业噪声
3. **避免因子集中** -- 多样化风险来源

> 来源: WQ_NEUTRALIZATION_GUIDE.md

### 4.2 中性化方法对比

| 方法 | 实现 | 效果 | 适用场景 |
|------|------|------|---------|
| Market Neutral | `group_zscore(x, market)` | 移除市场beta | 市场中性策略 |
| Industry Neutral | `group_zscore(x, industry)` | 移除行业因素 | 最常用，推荐首选 |
| Sector Neutral | `group_zscore(x, sector)` | 移除板块因素 | 板块间选股 |
| Sub-Industry | `group_zscore(x, subIndustry)` | 细粒度行业中性 | 精细化中性化 |
| Factor Neutral | `regression_residual(x, factor)` | 移除特定因子 | 高级用法 |
| Custom Neutral | `group_neutralize(x, bucket(rank(cap), "0,1,0.1"))` | 自定义分组 | 按市值等自定义维度 |

### 4.3 中性化层次选择指南

| 级别 | 何时使用 | 权衡 |
|------|---------|------|
| **子行业(SUBINDUSTRY)** | 选股alpha最常用默认 | 去除细粒度行业效应，"甜区" |
| **行业(INDUSTRY)** | 子行业分组过细时 | 比子行业多些信号自由度 |
| **板块(SECTOR)** | 更广泛的基本面/宏观信号 | 较粗糙;允许子行业间变异 |
| **市场(MARKET)** | 纯市场中性(零beta) | 最激进的中性化 |
| **无(NONE)** | 仅特定regime/宏观alpha | 高回撤风险;很少通过 |

**实战建议：**
- 从子行业中性化开始
- 在所有中性化级别上测试 alpha
- 一个级别上表现急剧下降 = 信号脆弱
- 基本面因子(盈利、估值)用板块或行业中性化更有效

> 来源: WQ_ALPHA_OPTIMIZATION_HANDBOOK.md

### 4.4 六脉神剑中性化进化路径

**Good -> Excellent -> Spectacular：**

```
// Good: 基础行业中性化 (Sharpe 1.2-1.5)
group_neutralize(alpha_expr, subindustry)

// Excellent: 向量中性化 (Sharpe 1.5-2.0)
group_vector_neut(alpha_expr, ts_mean(returns, 20), subindustry)

// Spectacular: 回归中性化 (Sharpe 2.0+)
regression_neut(
  vector_neut(rank(ts_delta(close, 5)), ts_mean(returns, 20)),
  [mdl175_size, mdl175_value, mdl175_volatility]
)
```

| 级别 | Sharpe | Drawdown | OS稳定性 | 构建难度 |
|------|--------|----------|---------|---------|
| Good | 1.2-1.5 | 10-15% | 一般 | 低 |
| Excellent | 1.5-2.0 | 5-10% | 良好 | 中 |
| Spectacular | 2.0+ | <5% | 优秀 | 高 |

> 来源: WQ_ALPHA_MASTER_CLASS.md

### 4.5 vector_neut 深度理解

`vector_neut(X, Y)` 移除 X 在 Y 上的投影 -> X* 与 Y 无线性关系。

**关键约束：**
- 需 Master 级别（10K+ 积分）解锁
- 自2025年起限制为高级顾问使用
- 替代方案：自行构建风险因子替代

**最佳实践：**
- X 和 Y 应有较高相关性才有意义
- 用于降低与现有组合的相关性
- `group_vector_neut(alpha, risk_factor, group)` 结合分组和正交化

> 来源: WQ_NEUTRALIZATION_GUIDE.md, WQ_FORUM_INSIGHTS.md

### 4.6 双重中性化与自定义分组

```
// 双重中性化
group_neutralize(group_neutralize(alpha, subindustry), market)

// 自定义分组（按市值分5组）
CUSTOM_GROUP = bucket(rank(cap), range="0,1,0.2")
group_neutralize(alpha, CUSTOM_GROUP)

// 笛卡尔积分组
group_cartesian_product(industry, bucket(rank(cap), "0,1,0.1"))
```

> 来源: WQ_NEUTRALIZATION_GUIDE.md

---

## 五、IQC 竞赛指南

### 5.1 比赛时间线 (2026)

| 事件 | 日期 |
|------|------|
| 报名开放 | 2026年3月17日 |
| 报名截止 | 2026年5月13日 |
| 第一阶段资格赛 | 3月17日 - 5月18日 |
| 第二阶段全国/地区赛 | 5月26日 - 7月中旬 |
| 第三阶段全球总决赛 | 2026年9月（新加坡） |

> 来源: WQ_IQC2026_GUIDE.md

### 5.2 关键规则

- 团队规模：1-4 人（同一所大学）
- 奖金池：$100,000（冠军 $20,000）
- **同团队 Alpha 相关系数不能超过 0.7**
- 前 20% 队伍晋级 Stage 1
- 每国家/地区前 8 支队伍晋级 Stage 2
- 2025 年参赛规模：~80,000 人，263,000+ Alpha

### 5.3 相关系数惩罚机制

| 条件 | 阈值 | 操作 |
|------|------|------|
| 低相关 | < 0.7 | 可提交 |
| 高相关 + 更高 Sharpe | > 0.7 且 new_sharpe > existing_sharpe * 1.1 | 可提交 |
| 高相关 + 更低 Sharpe | > 0.7 且 new_sharpe <= existing_sharpe * 1.1 | 不可提交 |

计算：每日收益的 Pearson 相关（基于 PnL 序列），窗口 4 年，仅与同区域 alpha 比较。

### 5.4 评分机制

```
Score = Sharpe x (1 - Penalty)
```

Penalty 来自：高 Turnover（指数级）、低 Fitness、高自相关、平台检查失败（一票否决）。

平台实际评分非线性处理：
- Sharpe > 1.8: 用 log 缩放
- Fitness > 1.2: 用 log 缩放
- 多项检查全部通过 = 10分，任一失败 = 0分

### 5.5 提交前质量控制

| 指标 | 最低 | 推荐 |
|------|------|------|
| Sharpe Ratio | 1.25 | > 1.5 |
| Fitness | 1.0 | > 1.5 |
| 自相关(self_corr) | < 0.7 | < 0.4 |
| Turnover | [0.01, 0.7] | ~0.125 |
| Long+Short count | > 100 | > 200 |
| 最大失败测试次数 | 2 | 0 |

> 来源: WQ_IQC2026_GUIDE.md, WQ_IQC_WINNER_STRATEGIES.md

### 5.6 冠军策略

**2025 冠军 Kim Min-gyeom（UNIST，韩国）：**
- 仅 32 个 Alpha（其他团队 200-300 个）
- "少而精" 哲学：组合统一后强于各部分之和
- 宏观经济 4 阶段框架：低利率、高利率、扩张、衰退
- 核心模型：Long/Short Equity + 新闻动量 + 隐含波动率
- 名言："数学推理固然关键，但成功取决于人类的哲学和洞察力"

**2023 冠军 Donghwa Seo（KAIST，韩国）：**
- 经常阅读学术论文获取灵感
- 探索自动化 Alpha 开发流程
- "最难的是过滤掉好看但过拟合的 Alpha"
- "传统智慧往往是正确的"

> 来源: WQ_IQC_WINNER_STRATEGIES.md

### 5.7 AI 时代的竞赛策略

- 2025 年纯 AI 策略表现不佳 -- 人类判断仍不可替代
- 2026 年公式：**人类洞察 + AI 效率 = 最优解**
- 优势转移：从"谁技术最好" -> "谁会问正确的问题和做最准的决策"

### 5.8 Stage 1 准备清单

- 组建 2-4 人团队
- 分配数据集覆盖（每人 2-3 个不同数据集）
- 建立团队 Alpha 库（目标 50-100 个高质量 Alpha）
- 检查团队内 Alpha 自相关（全部 < 0.7）
- 监控 IQC Score 更新（每 2 小时刷新）
- 每日至少提交 1-2 个新 Alpha

---

## 六、因子优化

### 6.1 Turnover 降低技术（按有效性排序）

| 排名 | 方法 | 操作符 | 效果 |
|------|------|--------|------|
| 1 | 目标换手率优化 | `ts_target_tvr_hump(x, 0, 1, 0.1)` | 动态调整至目标换手率 |
| 2 | hump 控制 | `hump() / hump_decay()` | 限制高频数据过度变化 |
| 3 | 预处理缺失值 | `ts_backfill() / group_backfill()` | 减少换手率尖峰 |
| 4 | 条件交易过滤 | `trade_when(cond, alpha, -1)` | 只在条件满足时交易 |
| 5 | 线性衰减平滑 | `ts_decay_linear()` | 加权平均降噪 |
| 6 | 固定持有 | `ts_delay()` | 固定天数持有信号 |
| 7 | 指数衰减 | `ts_decay_exp_window()` | 指数平滑 |

**最后手段：** 增加 decay 设置 -- 会削弱信号本身。官方明确建议优先用操作符降换手而非增加 decay。

> 来源: WQ_ALPHA_OPTIMIZATION_HANDBOOK.md, WQ_FORUM_INSIGHTS.md

### 6.2 Decay 调整指南

**基于 Turnover 的 Decay 调整：**

| Turnover | Decay 调整 |
|----------|-----------|
| > 0.7 | decay = decay * 4 |
| > 0.6 | decay = decay * 3 + 3 |
| > 0.5 | decay = decay * 3 |
| > 0.4 | decay = decay * 2 |
| > 0.35 | decay = decay + 4 |
| > 0.30 | decay = decay + 2 |

**Decay 与 Turnover 的定量关系：**
```
Turnover(decay=d) = Turnover(decay=1) / sqrt(d)
```
decay 从 1 增到 4 -> Turnover 约减半。

> 来源: WQ_ALPHA_OPTIMIZATION_HANDBOOK.md

### 6.3 Decay 按策略类型推荐

| 策略类型 | 常用 Decay | 最佳范围 |
|---------|-----------|---------|
| 短期均值回归 | 2-4 | 2-5 |
| VWAP 策略 | 15 | 10-15 |
| 基本面策略 | 4-5 | 4-9 |
| 新闻情绪策略 | 3-10 | 3-10 |
| 动量策略 | 3-6 | 3-8 |
| 波动率策略 | 5-10 | 5-10 |

### 6.4 Decay 稳健性测试

- 若 decay >= 5：扰动 +-5
- 若 decay < 5：测试 decay+10 和 decay+20
- 在 4 和 6 之间犹豫时，用 5 或将两者平均（避免精确调参 -> 过拟合）

### 6.5 截断（Truncation）设置

| 值 | 效果 | 适用场景 |
|---|------|---------|
| 0.08 | 默认，宽松 | 覆盖度高的 Alpha |
| 0.03-0.05 | 中等 | 通用 |
| 0.01-0.02 | 严格 | 覆盖度低或极端值多 |
| 0.005 | 最严格 | 权重极度集中时 |

- 低截断 = 更紧的边界 = 更分散的权重
- 先用 `rank()` 自然解决权重集中，再调 truncation
- 过低 truncation (< 0.01) 会显著降低收益

### 6.6 提高 Sharpe 的分阶段流程

**阶段 1 (Sharpe 1.2-1.4):** 添加分组操作 -- `group_neutralize` / `group_rank` / `group_zscore`

**阶段 2 (Sharpe 1.4-1.58):** 条件逻辑 -- `trade_when(alpha, ts_rank(ts_std(returns, 60), 126) > 0.55, alpha)`

**阶段 3 (Sharpe > 1.58):** 高级技巧 -- 回归中性化、向量中性化、多因子嵌套

> 来源: WQ_ALPHA_OPTIMIZATION_HANDBOOK.md

### 6.7 D0 vs D1 策略选择

| 维度 | D0 | D1 |
|------|-----|-----|
| 交易时间 | 当天收盘 | 次日开盘 |
| 数据使用 | 当天数据(收盘价等) | 使用截至当天的数据 |
| 通过要求 | 更高(USA D0门槛更高，通常>2.0视区域动态调整) | 标准(D1=2.0) |
| 适合 | 短期/盘中信号 | 大多数策略 |
| 基本面数据集 | 价值低(自然延迟) | 更合适 |

**建议：** 从 D1 开始，使用 D0 数据尝试组均值回归，使用新闻数据作为事件触发器。

> 来源: WQ_ALPHA_OPTIMIZATION_HANDBOOK.md

### 6.8 IC Decay 指导 Decay 参数

```
最佳 Decay = IC 半衰期 * 2
```

| IC Decay 形态 | 含义 | 最佳持有期 |
|--------------|------|-----------|
| 快速衰减(1-3天后IC接近0) | 短期反转/噪声 | 1-2天(D0) |
| 中等衰减(5-20天) | 动量/趋势 | 5-10天 |
| 缓慢衰减(>60天) | 基本面/价值 | 20-60天 |

---

## 七、数据集与字段

### 7.1 数据类别总览

| 类别 | 价值评分 | 数据集 | 字段数 | 说明 |
|------|---------|--------|--------|------|
| Model | 7 | model51/55/77 | 3,296 | 风险指标、复合因子 |
| Sentiment | 7 | sentiment1 | 20 | 综合情绪 |
| Option | 6 | option8/9 | 138 | 期权、波动率 |
| Analyst | 5 | analyst4/7/14 | 1,374 | 分析师预测 |
| Fundamental | 3 | fundamental2/6 | 1,758 | 财务报表 |
| News | 3 | news12/18 | 1,021 | 新闻情绪 |
| Price Volume | 2 | pv1/pv13 | 202 | 量价基础 |
| Social Media | 2 | socialmedia12 | 22 | 社交媒体 |

> 来源: WQ_DATASET_FIELDS_REFERENCE.md, WQ_BRAIN_PLATFORM_GUIDE.md

### 7.2 各数据集专项策略

| 数据集 | 最高 Sharpe | 最佳 Decay | 特殊处理 | 核心建议 |
|--------|-----------|-----------|---------|---------|
| fundamental6 | 2.0-2.5 | 4-9 | 基本无需 | 盈利收益率/质量型表达 |
| analyst4 | 1.8-2.3 | 3-5 | TOP1000限制 | 分析师修正型表达 |
| pv1 | 1.5-2.5 | 2-5 | 换手率控制关键 | hump/trade_when必须 |
| option8 | 1.5-2.0 | 3-6 | 字段选择关键 | 波动率偏斜/排名 |
| news12 | 1.5-2.0 | 3-10 | ts_backfill必须 | hump是最佳选择 |
| model77 | 2.0-3.0 | 5-15 | 基本不需 | 高decay效果更好 |
| nws77 | 1.8-2.5 | 5-10 | vec_*聚合+backfill | 成功率~0.57%但独特 |

### 7.3 按数据集选择操作符

| 数据集 | 优先操作符 | 避免 |
|--------|-----------|------|
| fundamental6 | ts_rank, ts_mean, group_neutralize | trade_when (无需降换手) |
| analyst4 | ts_delta, rank, group_rank | 复杂ts_ops (样本小) |
| pv1 | ts_delta, ts_std, ts_corr, trade_when | 高decay (信号衰减快) |
| option8 | ts_std, power, group_rank | 低窗口 (数据稀疏) |
| news12 | ts_backfill, vec_avg, hump, trade_when | ts_mean (窗口需匹配事件频率) |
| model51/77 | ts_zscore, ts_rank, signed_power | trade_when (信号本身已稳定) |

> 来源: WQ_PER_DATASET_STRATEGIES.md

### 7.4 数据集间相关系数（跨数据集组合价值）

| 数据集对 | 典型相关系数 | Alpha组合价值 |
|---------|------------|--------------|
| pv1 x fundamental6 | 0.15-0.25 | 高（不同信号源） |
| pv1 x news12 | 0.05-0.15 | 非常高（正交信号） |
| fundamental6 x news12 | 0.05-0.10 | 非常高 |
| model77 x news12 | 0.05-0.15 | 非常高 |
| pv1 x model77 | 0.30-0.45 | 中（量价 vs 风险模型） |
| fundamental6 x analyst4 | 0.25-0.40 | 中高（不同视角） |

### 7.5 字段类型与处理

| 类型 | 描述 | 处理方式 |
|------|------|---------|
| MATRIX | 每股票每天一个值 | 直接使用 |
| VECTOR | 每股票每天多个值 | 需 `vec_avg()` 或 `vec_sum()` 聚合 |
| GROUP | 分组字段 | 用于 `group_neutralize`, `group_rank` 的参数 |

### 7.6 字段筛选策略

**alphaCount 阈值法：**
- model77: 固定 alphaCount >= 100
- 其他: 字段数<500全跑, >=500取前1/3
- 高覆盖 + 中等使用量(alphaCount 50-500) = 最优选择

### 7.7 覆盖度问题处理

各字段典型覆盖度与填充策略：

| 字段类型 | 原始覆盖度 | 120天填充后 | 推荐策略 |
|---------|-----------|------------|---------|
| fnd6_* | 60-80% | 85-95% | 120天足够 |
| anl4_* | 20-40% | 40-60% | 结合group_backfill |
| pv1_* | 90-100% | 无需填充 | 不处理 |
| news12_* | 1-5% | 15-30% | 必须vec_avg+长窗口 |
| nws77_* | 1-3% | 10-25% | vec_max+长窗口 |
| model77_* | 85-95% | 95-98% | 基本不需处理 |

> 来源: WQ_WEIGHT_TEST_COVERAGE.md

---

## 八、过拟合防止与稳健性

### 8.1 过拟合 -- 头号大忌

**症状：** 历史回测优秀但样本外/实盘失败。

**判断标准：**
- OS Sharpe / IS Sharpe > 0.7 -> 正常
- 0.5-0.7 -> 轻度过拟合，需简化
- < 0.5 -> 严重过拟合，不可提交
- IS Fitness - OS Fitness > 0.6 -> 过拟合

> 来源: WQ_ROBUSTNESS_OVERFITTING.md, WQ_SIMULATION_METRICS_GUIDE.md

### 8.2 8项扰动测试

1. **Decay 扰动**: decay>=5 时测试+-5; <5 时测试+10/+20
2. **中性化扰动**: SUBINDUSTRY -> INDUSTRY -> SECTOR -> MARKET 遍历
3. **宇宙变动**: TOP1000, TOP500 等子宇宙测试
4. **变量移除**: 每次移除一个输入变量
5. **窗口偏移**: 不同历史窗口
6. **行业集中度**: 检查对特定行业过度暴露
7. **排序测试**: alpha值排序后收益是否单调
8. **二元测试**: 将alpha转为多/空二元信号

通过条件：最多2次测试失败，Sharpe保留率>=60%。

### 8.3 洗牌测试 (Shuffle Test)

1. 保持alpha信号不变
2. 将目标收益时间序列随机打散
3. 重新计算Sharpe/IC
4. 重复100次得到随机分布
5. 原始Sharpe显著高于95%分位数 -> 信号真实; 落在内部 -> 可能过拟合

### 8.4 最佳实践

| 原则 | 细节 |
|------|------|
| **简洁优先** | 简单因子泛化能力更强 |
| **参数平均** | 在4或6天decay之间选5天或取平均 |
| **不选最优** | 次优通常过拟合倾向更低 |
| **标准窗口** | 只用5,10,20,60,120,252, 避免37,83等 |
| **训练/测试分割** | 样本内分训练和验证期，只保留两者都好的 |
| **经济逻辑** | 能解释为什么有效才行 |

### 8.5 101 Alpha 警告

WorldQuant 发布的 101 Alphas 包含**故意混淆参数**（如 3.67819 天）。这些不是真正最优值。参考逻辑而非具体数字。

> 来源: WQ_ROBUSTNESS_OVERFITTING.md

---

## 九、投资组合与相关性管理

### 9.1 相关系数计算机制

```
每日收益 = PnL(t) - PnL(t-1).ffill()
Pearson 相关系数 = corr(新alpha每日收益, 已有alpha每日收益)
```

- 窗口：滚动 4 年 PnL 数据
- 仅与同一区域 alpha 比较
- 数据源：OS（样本外）PnL 序列

> 来源: WQ_PORTFOLIO_CORRELATION.md

### 9.2 Triple Axis Plan (TAP) 多样化框架

在三个轴上系统探索 alpha 空间：
1. **数据类别**：基本面、PV、分析师、情绪、模型、期权、新闻
2. **想法类型**：均值回归、动量、价值、质量、波动率、增长
3. **持有频率/延迟**：D0、D1、不同 decay 值

**策略：** 冻结一个轴，系统探索另外两个。

### 9.3 降低相关性的技术

**方法 1：使用不同数据集族** -- 不同数据集类型天然低相关

**方法 2：不同中性化设置**
- 子行业中性化：细粒度行业效应
- 市场中性化：纯市场中性
- 自定义中性化：`CUSTOM_GROUP = floor(rank(cap)*4.99)`

**方法 3：vector_neut 正交化**
```
vector_neut(new_alpha, existing_portfolio_return)
```

**方法 4：多样化衰减窗口**
- 短窗口(5-22天)：短期反转/动量
- 中窗口(60-120天)：趋势
- 长窗口(240-500天)：基本面缓慢变化

### 9.4 组合权重分配

| 方法 | 说明 | 适用场景 |
|------|------|---------|
| 等权重 | 最简单最常用 | 通用（推荐入门） |
| 1/Turnover 加权 | 低换手率更高权重 | Fitness优化 |
| 自相关倒数加权 | 低自相关更高权重 | 独特性优先 |
| 动态协方差加权 | IC协方差矩阵求最优权重 | 高级 |

### 9.5 Alpha 衰减管理

- Alpha 衰减是自然现象：市场条件变化、竞争侵蚀信号
- 防止措施：
  1. 滚动窗口计算（非固定窗口）
  2. 制度切换模型（volume 作为 regime proxy）
  3. 低相关 alpha 多样化（至少 5-8 个不相关）
  4. 稳健回测（4 年窗口，多种中性化设置）

> 来源: WQ_PORTFOLIO_CORRELATION.md, WQ_FORUM_INSIGHTS.md

---

## 十、Weight Test 与覆盖度

### 10.1 Weight Test 失败原因

单只股票权重超过投资组合的 10%。触发因素：
- 低覆盖度（数据字段覆盖股票太少）
- 分布偏斜（alpha值极端分布）
- 多空不平衡
- 异常值

### 10.2 解决方案（按推荐顺序）

1. **使用 `rank()`** -- 最简单有效，均匀分布权重
2. **降低 Truncation** -- 0.08 -> 0.01
3. **`ts_backfill(field, 120)`** -- 提高覆盖度
4. **`group_backfill(field, 120, subindustry)`** -- 组内填充更精确
5. **`if_else(is_nan(field), group_mean(field, 1, subindustry), field)`** -- 条件替换
6. **`winsorize(field, std=4)`** -- 处理异常值
7. **`scale()` / `zscore()`** -- 归一化

> 来源: WQ_WEIGHT_TEST_COVERAGE.md

---

## 十一、区域策略

### 11.1 各区域特征速查

| 区域 | 宇宙 | 特点 | 推荐策略 |
|------|------|------|---------|
| **USA** | TOP3000 | 数据最全，竞争最激烈 | 基本面+模型+情绪 |
| **CHN** | TOP2000U | 高Sharpe潜力，2015回撤注意 | 低波+价值，关注2016后 |
| **EUR** | TOP2500 | 分析师数据质量高 | 分析师修正+估值因子 |
| **JPN** | TOP3000 | 治理改革红利，低波传统 | 价值+治理改善 |
| **ASI** | MINVOL1M | 多市场混合 | 动量+低波 |
| **GLB** | TOP3000 | 覆盖面最广 | 跨市场多样化 |

### 11.2 区域具体建议

**CHN：**
- Decay: 1-5（信号衰减快）
- 中性化: subindustry 或 industry
- 关注2016年后表现，不要拟合2015极端市场
- 高Sharpe模板：`rank(-mdl175_volatility * log(volume))`

**EUR：**
- 数据集优先级: analyst4 > fundamental6 > pv1 > model51
- Decay: 3-7
- 分析师修正型表现优异

**JPN：**
- Decay: 5-10（信号更持久）
- 价值溢价持续，治理改革创造新机会
- 低波异象有效

**USA：**
- 竞争最激烈，基本面因子表现好
- PV alpha 用 250 天窗口（官方建议）
- 价值-质量交叉型 + 低波+动量组合

> 来源: WQ_REGION_STRATEGIES.md

---

## 十二、常见陷阱与失败模式

### 12.1 平台技术错误

| 错误 | 原因 | 解决 |
|------|------|------|
| Unit Incompatibility Warning | 不同量纲字段运算 | 用 rank()/zscore() 标准化（或安全忽略） |
| Weight Concentration | 单只股票权重>10% | rank() + 降低truncation + ts_backfill |
| Self-Correlation Error | 与已有alpha相关>0.7 | 换数据集/操作符组合 |
| Simulation Stuck | 数据集稀疏/表达式复杂 | 简化表达式/降低宇宙规模 |
| Concurrent Simulations | 超过3个并发 | 等待其他完成 |

### 12.2 模拟失败模式

| 失败类型 | 原因 | 解决方案 |
|---------|------|---------|
| Weight Test | 单只权重>10% | rank()替代原始值，降低truncation |
| Low Sharpe | Sharpe<1.25 | group_neutralize + trade_when |
| High Turnover | Turnover>70% | hump()/ts_decay_linear()/增加decay |
| Low Fitness | Fitness<1.0 | 同时提升Sharpe和降低Turnover |
| Self-Correlation | PnL相关>0.7 | 更换数据集/操作符组合 |
| 覆盖度不足 | Long+Short<100 | ts_backfill(field, 120)填充NaN |

### 12.3 综合诊断流程

```
1. 检查 Sharpe -> < 1.25? -> 加 neutralization/条件逻辑
2. 检查 Turnover -> > 0.7? -> 加 hump/trade_when/decay
3. 检查 Fitness -> < 1.0? -> 同时改善 Sharpe + Turnover
4. 检查 Drawdown -> > 15%? -> 加中性化/降 truncation
5. 检查 Decile -> 非单调? -> 检查数据质量/过拟合
6. 检查 OS vs IS -> 差异大? -> 简化表达式/减少参数
7. 检查 Self-Corr -> > 0.7? -> 多样化数据集或操作符
```

> 来源: WQ_SIMULATION_METRICS_GUIDE.md, WQ_TROUBLESHOOTING.md

### 12.4 Consultant 常见错误

| 错误 | 后果 | 解决方案 |
|------|------|---------|
| 过拟合 | OS崩盘 | 简化表达式，用Train/Test Split |
| 参数拟合 | 非标准窗口37/83天 | 只用5,10,20,60,120,250 |
| 集中做多 | Weight Test失败 | 确保多空平衡 |
| 忽略覆盖度 | 权重集中 | 预处理ts_backfill |
| 冗余提交 | 自相关错误 | 多样化数据集和操作符 |
| 中断提交 | 季度奖金资格丧失 | 至少每月20天有提交 |
| 过度neutralization | 信号消失 | 逐层测试中性化强度 |

> 来源: WQ_ALPHA_MASTER_CLASS.md

### 12.5 关键安全规则

- **绝对不能误点 Submit Alpha** -- 提交后无法删除或撤回
- Alpha 提交前必须仔细检查 Performance Comparison
- Alpha 提交后无法撤回，后果不可逆
- 数据集无法直接下载到本地

### 12.6 API 错误码

| 状态码 | 含义 | 处理 |
|--------|------|------|
| 201 | 成功 | 正常 |
| 400 | 请求错误 | 检查表达式和参数 |
| 401 | 未授权 | Token过期->重新认证 |
| 403 | 禁止 | 账号停用->联系支持 |
| 429 | 限流 | 等待60s+指数退避 |
| 500 | 服务器错误 | 重试 |

> 来源: WQ_TROUBLESHOOTING.md

---

## 十三、快速参考卡 (Cheat Sheet)

### 最常用操作符 Top 10（完整签名）

| 操作符 | 完整语法 | 参数说明 | 示例 |
|--------|---------|---------|------|
| `rank(x)` | 截面排名→[0,1] | x: 任意表达式 | `rank(ts_delta(close, 5))` |
| `ts_rank(x, d)` | d天时序排名 | x: 表达式, d: 回溯天数 | `ts_rank(returns, 20)` → 0-1 |
| `ts_delta(x, d)` | x[t] - x[t-d] | x: 表达式, d: 滞后天数 | `ts_delta(close, 5)` → 价格变化 |
| `ts_mean(x, d)` | d天滚动均值 | x: 表达式, d: 窗口天数 | `ts_mean(volume, 20)` → 均量 |
| `ts_zscore(x, d)` | (x-μ[d])/σ[d] | x: 表达式, d: 窗口天数 | `ts_zscore(close, 60)` |
| `ts_std(x, d)` | d天滚动标准差 | x: 表达式, d: 窗口天数 | `ts_std(returns, 60)` |
| `group_neutralize(x, g)` | x - group_mean(x,g) | x: 信号, g: 分组字段 | `group_neutralize(a, subindustry)` |
| `group_rank(x, g)` | 组内截面排名 | x: 信号, g: 分组字段 | `group_rank(a, sector)` → 0-1 |
| `trade_when(c, a, f)` | 条件满足→a, 否则→f | c: 布尔条件, a: 信号, f: 回退值 | `trade_when(volume > adv20, a, -1)` |
| `ts_backfill(x, n)` | NaN前向填充 | x: 表达式, n: 最大填充天数 | `ts_backfill(field, 120)` |

### 其他常用操作符（完整签名）

| 操作符 | 完整语法 | 示例 |
|--------|---------|------|
| `ts_corr(x, y, d)` | 时序滚动相关系数 | `ts_corr(close, volume, 20)` |
| `ts_sum(x, d)` | d天滚动求和 | `ts_sum(returns, 5)` |
| `ts_max(x, d)` / `ts_min(x, d)` | d天滚动最大/最小值 | `ts_max(high, 20)` |
| `ts_delay(x, d)` | x[t-d]（向前看） | `ts_delay(close, 1)` |
| `ts_decay_linear(x, d)` | 线性衰减加权均值 | `ts_decay_linear(returns, 5)` |
| `ts_regression(y, x, d, lag=0, rettype=0)` | 滚动回归 y~x; rettype: 0=系数,1=残差,2=R² | `ts_regression(close, vwap, 4, lag=0, rettype=2)` |
| `ts_arg_max(x, d)` | d天内最大值距今天数 | `ts_arg_max(volume, 5)` |
| `signed_power(x, e)` | sign(x)·|x|^e | `signed_power(returns, 2)` |
| `zscore(x)` | 截面z-score标准化 | `zscore(returns)` |
| `demean(x)` | 截面去均值 | `demean(close)` |
| `winsorize(x, std=4)` | 缩尾异常值 | `winsorize(field, 4)` |
| `quantile(x, method)` | 分布重塑 | `quantile(alpha, "gaussian")` |
| `group_zscore(x, g)` | 组内z-score | `group_zscore(a, industry)` |
| `group_backfill(x, d, g)` | 组内填充NaN | `group_backfill(field, 120, subindustry)` |
| `hump(x, threshold)` | 变化>阈值更新 | `hump(alpha, 0.01)` |
| `if_else(c, a, b)` | 条件选择 | `if_else(close > open, 1, -1)` |
| `vector_neut(x, y)` | x对y正交化(需Master) | `vector_neut(alpha, risk_factor)` |
| `bucket(x, range)` | 自定义分桶 | `bucket(rank(cap), "0,1,0.1")` |
| `log(x)` / `exp(x)` / `sqrt(x)` | 数学函数 | `log(abs(returns)+1)` |
| `vec_avg(field)` / `vec_sum(field)` | VECTOR字段聚合 | `vec_avg(news_sentiment)` |
| `ts_target_tvr_hump(x, lo, hi, tgt)` | 目标换手率控制 | `ts_target_tvr_hump(alpha, 0, 1, 0.1)` |

### 最有用字段类别

| 优先级 | 类别 | 数据集 |
|--------|------|--------|
| 1 | 模型 | model77 (复合因子，表现最稳定) |
| 2 | 基本面 | fundamental6 (盈利/价值/质量) |
| 3 | 情绪 | sentiment1, news12 (独特信号) |
| 4 | 量价 | pv1 (基础，高频) |
| 5 | 分析师 | analyst4 (预期修正) |
| 6 | 期权 | option8 (波动率维度) |

### 高胜率构建公式

```
// 基本面价值 (USA Sharpe 2.03)
rank(ts_rank(fnd6_epsfx / close, 40))

// 波动率+成交量 (CHN Sharpe 5.03)
rank(-mdl175_volatility * log(volume)) * (1 + group_rank(mdl175_revenuettm, subindustry))

// VWAP回归
(vwap - close) / vwap

// 价格反转
rank(ts_mean(close, 30) - close)

// 质量-波动率组合
group_neutralize(ts_zscore(ts_delta(close,5), 120), subindustry)
```

### 最优起始参数（"甜区"）

| 参数 | 推荐值 | 备选 |
|------|--------|------|
| 中性化 | SUBINDUSTRY | INDUSTRY 用于宏观信号 |
| Decay | 4 | 基本面=4-9, 量价=2-5 |
| 截断 | 0.08 (TOP3000) | 0.01 (更集中) |
| Delay | 1 (更保守) | 0 (更激进) |
| Pasteurization | ON | 始终开启 |
| 操作符数量 | <=5 | 重复算1个 |
| NaN Handling | OFF (手动ts_backfill) | 根据数据集 |

### 合格 Alpha 画像

```
Sharpe:     >= 1.5 (D1) / >= 2.0 (D0)
Turnover:   5% - 30%
Fitness:    >= 1.3
Drawdown:   < 10%
Decile:     单调递减, spread显著
OS vs IS:   一致 (OS/IS Sharpe > 0.7)
Self-Corr:  < 0.7
Long+Short: > 200
```

### 一句话黄金法则

1. **永远从 `rank()` 开始** -- 解决90%的权重问题
2. **永远做 `ts_backfill(field, 120)`** -- 解决覆盖度问题
3. **永远用标准窗口(5,22,60,120,252)** -- 避免过拟合
4. **永远至少做 subindustry 中性化** -- 提升稳健性
5. **优先用操作符降换手而非增加 decay** -- 保持信号强度
6. **操作符总数 <= 5** -- 简洁是王道
7. **能解释逻辑的 Alpha 才是好 Alpha** -- 过拟合的往往是黑箱
8. **提交前检查 Performance Comparison** -- 提交=不可逆

---

## 附录：文档来源索引

本文档整合自以下 WQ 知识体系文档（2026年5月）：

**核心 WQ 专题文档（21篇）：**
- WQ_ULTIMATE_KNOWLEDGE_BASE.md (2.3MB 终极合并版)
- WQ_BRAIN_PLATFORM_GUIDE.md (平台操作指南)
- WQ_NEUTRALIZATION_GUIDE.md (127KB 中性化深度指南)
- WQ_HIGH_SHARPE_PATTERNS.md (高Sharpe模式库)
- WQ_ALPHA_OPTIMIZATION_HANDBOOK.md (优化手册)
- WQ_ALPHA_MASTER_CLASS.md (六脉神剑技术系统)
- WQ_OPERATORS_ENCYCLOPEDIA.md (操作符百科全书)
- WQ_SIMULATION_METRICS_GUIDE.md (指标解读)
- WQ_PORTFOLIO_CORRELATION.md (组合多样化)
- WQ_ROBUSTNESS_OVERFITTING.md (过拟合防御)
- WQ_TROUBLESHOOTING.md (常见问题)
- WQ_DATASET_FIELDS_REFERENCE.md (数据集字段)
- WQ_IQC2026_GUIDE.md (竞赛指南)
- WQ_IQC_WINNER_STRATEGIES.md (冠军策略)
- WQ_ALPHA_PATTERN_LIBRARY.md (模式库)
- WQ_PER_DATASET_STRATEGIES.md (数据集策略)
- WQ_FORUM_INSIGHTS.md (论坛洞察)
- WQ_CONSULTANT_GUIDE.md (顾问计划)
- WQ_REGION_STRATEGIES.md (区域策略)
- WQ_FASTEXPR_LANGUAGE_GUIDE.md (语言参考)
- WQ_WEIGHT_TEST_COVERAGE.md (权重覆盖度)

**学术理论文档：**
- 美股量化因子构建实战.md (155KB 美股因子从经典到高阶)
- 因子投资理论基础与前沿.md (CAPM->FF5->因子动物园)
- Alpha因子构建方法大全.md (12大类因子)
- 其余 28 篇学术理论文档
