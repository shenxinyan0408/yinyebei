# A股量化因子回测平台

基于 Flask + NumPy 的量化因子回测系统，支持自定义表达式输入、15种时序/截面操作符、122个数据字段（含分钟级日内数据）。

## 快速启动

```bash
# 1. 安装依赖
cd backtest_platform
pip install -r requirements.txt

# 2. 放置数据文件到项目根目录（需自行准备）
#    - DailyDataYYYYMMDDopen.bin （日频 OHLCV）
#    - MinuteYYYYMMDD.mat × N （分钟K线，每天一个文件）
#    - 数据格式见 模型/data_pipeline.py

# 3. 启动
python app.py
# 访问 http://127.0.0.1:5000
# 默认账号: admin / quant2026
```

## 目录结构

```
├── backtest_platform/       # Flask 回测平台
│   ├── app.py               # 主程序（路由 + API + 回测逻辑）
│   ├── expression_parser.py # 因子表达式解析器
│   ├── requirements.txt     # Python 依赖
│   ├── backtest.db          # SQLite 数据库（自动创建）
│   ├── templates/           # HTML 模板
│   │   ├── login.html       # 登录注册页
│   │   ├── dashboard.html   # 仪表盘（指标卡片 + 图表）
│   │   ├── alpha_history.html  # Alpha 历史记录
│   │   ├── data_fields.html    # 数据字段百科全书
│   │   ├── operators.html      # 操作符参考
│   │   ├── correlation.html    # 相关性分析
│   │   ├── community.html      # 社区论坛
│   │   └── ...
│   └── static/
│       └── chart.umd.min.js    # Chart.js 图表库
│
└── 模型/                    # 核心计算模型
    ├── data_pipeline.py     # 数据加载（日频 .bin + 分钟 .mat）
    ├── backtest_framework.py # 回测引擎（IC/ICIR/分层收益）
    ├── factor_library.py    # 65个预计算因子 + 分钟数据聚合
    ├── full_pipeline.py     # 完整流水线执行入口
    └── final_factor.py      # 独立可运行的最终因子代码
```

## 功能模块

### 1. 因子表达式回测
- POST `/api/backtest` — 输入表达式，返回 IC/Sharpe/Fitness/PnL
- 支持多行代码（分号/换行分隔）、变量赋值
- 可选市值中性化：`neutralize=market_cap`

### 2. SuperAlpha 组合
- POST `/api/superalpha` — 等权组合（zscore 标准化 → 等权平均 → 回测）
- POST `/api/superalpha/lgb` — LightGBM 非线性组合

### 3. Alpha 管理
- GET `/api/alpha/history` — 历史记录
- POST `/api/alpha/compare` — 多因子对比
- POST `/api/alpha/correlation` — 相关性矩阵
- POST `/api/alpha/decay` — IC 衰减分析
- POST `/api/alpha/selfcorr` — 自相关性检查
- POST `/api/alpha/recompute_max_corr` — 重新计算最大相关性

### 4. 数据字段 (122个)

| 类别 | 字段示例 |
|------|---------|
| 价格类 | close, open, high, low, preclose |
| 收益类 | returns, ret_5d, ret_20d, ret_60d |
| 波动类 | vol_20d, vol_60d, downside_vol_60d |
| 反转类 | rev_1d, rev_5d, rev_overnight |
| 成交量类 | volume, turnover_rate, amihud_20d |
| 分钟衍生 | intraday_volatility, vwap_gap, price_efficiency, close_location |
| 微观结构 | volume_concentration, upper_shadow_pct, lower_shadow_pct |
| 日内时段 | morning_return, afternoon_return, first30min_return, last30min_return |
| 跨模态 | smart_money_vol, large_trade_ratio, vpin, roll_spread |
| 技术指标 | rsi_14, bollinger_pos, beta_60d |
| 质量 | sharpe_60d, hit_rate_60d, max_dd_60d, skewness_60d |

### 5. 操作符 (18个)

```
时序: ts_delta(x,d) ts_mean(x,d) ts_std(x,d) ts_rank(x,d) ts_max(x,d)
      ts_min(x,d) ts_sum(x,d) ts_corr(x,y,d) ts_delay(x,d)
      ts_decay_linear(x,d) ts_backfill(x) ts_regression(y,x,d,lag)
截面: rank(x) zscore(x) demean(x) signed_power(x,e)
分组: group_neutralize(x,group) group_rank(x,group) group_zscore(x,group)
```

### 6. 竞赛评分指标
- Pearson IC / Rank IC / ICIR / IC 胜率
- 年化超额收益（Top10%做多 - 市场平均）
- Sharpe / Sortino / Max Drawdown / Fitness
- Turnover / Margin / Win Rate

## 数据准备

需自备 A 股日频和分钟数据：

**日频 `DailyData20240102open.bin`:**
- joblib 序列化格式（Python `joblib.load()` 读取）
- 内容：dict，键为字段名，值为 float32 numpy 数组，形状 (n_dates, n_stocks)
- 必需字段：I_D_OPEN_ORI, I_D_CLOSE_ORI, I_D_HIGH_ORI, I_D_LOW_ORI, I_D_VOLUME, I_D_AMOUNT, I_D_PRECLOSE_ORI, I_D_ADJFACTOR, I_D_SHARE_FREESHARES, I_D_SHARE_LIQA, I_D_TOTAL_SHARES, I_D_MCAP, Label, CALENDAR_DF, STOCKLIST

**分钟 `MinuteYYYYMMDD.mat`:**
- MATLAB .mat 格式，每天一个文件
- 包含：MINUTE_OPEN, MINUTE_HIGH, MINUTE_LOW, MINUTE_CLOSE, MINUTE_VOLUME, MINUTE_AMOUNT, MINUTE_NUMBER
- 形状：(242, n_stocks) — 每天 242 根分钟 bar

## 10个表达式示例

| # | 表达式 | 说明 |
|---|--------|------|
| 1 | `rank(ts_delta(close, 20))` | 20日动量：截面排名最高的股票 |
| 2 | `-rank(ts_sum(close/open-1, 5))` | 5日反转：近期涨幅大的做空 |
| 3 | `rank(ts_mean(volume, 5) / ts_mean(volume, 20))` | 量比：短期放量 |
| 4 | `-signed_power(close/open-1, 2) * rank(volume)` | 异常量反转：放量下跌后反弹 |
| 5 | `rank(ts_std(close/open-1, 20))` | 波动率：高波动因子 |
| 6 | `ts_delta(close, 20) / (ts_std(close/open-1, 60) + 0.001)` | 夏普比近似：单位风险的动量 |
| 7 | `close / open - 1` | 日内收益：当日涨幅 |
| 8 | `rank(ts_corr(close/open-1, volume, 20))` | 量价相关性：量价同步性 |
| 9 | `group_neutralize(rank(ts_delta(close, 5)), market_cap)` | 市值中性动量：剔除市值影响 |
| 10 | `trade_when(volume > ts_mean(volume, 20), rank(ts_delta(close, 10)), -1)` | 条件因子：放量时做动量 |

## 常见错误

- **除零**: 除法分母必须加 eps，如 `/ (ts_std(x, 20) + 0.001)`
- **括号**: 表达式必须合法嵌套，每个函数调用后括号要闭合
- **字段不存在**: 确认使用平台支持的 122 个字段名（见数据字段页面）
- **ts_delta 混淆**: `ts_delta(close, 20)` 是价格差，`ts_delta(close/open-1, 20)` 是收益率差
- **量纲问题**: `close` 是元，`close/open-1` 是无量纲，不要混用

## 修改与自定义

修改 `expression_parser.py` 中的 `FIELDS_METADATA` 和 `DERIVED_FIELD_REGISTRY` 可添加新字段和因子。

修改 `factor_library.py` 中的 `FactorComputer` 类可添加新的预计算因子。

修改 `app.py` 中的 `_compute_metrics_from_result` 可自定义评分指标。

修改 `templates/` 下的 HTML 文件可自定义前端界面。
